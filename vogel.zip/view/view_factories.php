<?php
include '../connect.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>kit list</title>
</head>
<body>

  <div class="row" style="*background-image: linear-gradient(180deg, rgb(1, 88, 96,.8), #002437);color: white; height: 42vw;">
    <div class="col-md-3" style="float: right;">
      <form class="navbar-form" role="search">

        <input class="form-control" placeholder="Search" id="kit" type="text" style="background-color: white; margin-top: 1vw; color: black; float: right;">
      </form>
    </div>
    <h3  style="text-align: center;color: black;"><b>FACTORY LIST</b></h3>
    <div class="col-lg-12" style="height: 35.85vw; overflow: auto; ">
      <table border="1" class="table" id="kit_table" style="border-width: 2px;font-weight: bold; *background-color:red; color: black;">
        <thead style="*background-color: #008080; color: black;">



          <tr style="font-size: 1vw;">
<th style="width: 5vw;">SL NO:</th>

<th style="text-align: center;">Factory Name</th>
<th style="text-align: center;">Vendor Name</th>
<th style="text-align: center;">Address</th>
<th style="text-align: center;">Place</th>
<th style="*text-align: center; ">Action</th>

</tr>

</thead>
<tbody>
  <?php
  $query=mysqli_query($conn,"SELECT * FROM `vendors`");
  while($fetch=mysqli_fetch_array($query))
  {
   $vendor_id=$fetch["vendor_id"];
   $factory_name=$fetch["factory_name"];
   $vendor_name=$fetch["vendor_name"];
   $vendor_address=$fetch["vendor_address"];
   $vendor_place=$fetch["vendor_place"];
  
   
   ?>
   <tr>
     <td style="cursor: pointer;"> <?php echo $vendor_id;?> </td>
     <td style="cursor: pointer;"> <?php echo $factory_name;?> </td>
     <td style="cursor: pointer;"> <?php echo $vendor_name;?> </td>
     <td style="cursor: pointer;"> <?php echo $vendor_address;?> </td>
     <td style="cursor: pointer;"> <?php echo $vendor_place;?> </td>
     <td> <button class="btn  btn-success active" style="height: 2.5vw;" onclick="edit_factory('<?php echo $vendor_id;?>');"> Edit </button> &nbsp <a href="view/vendor_view.php?vendor_id=<?php echo $vendor_id;?>"><button class="btn  btn-primary active" style="height: 2.5vw;"> Print</button></a></td>
    
     
   </tr>
    <?php

}
?>
</tbody>
</table>
</div>
</div>

<script type="text/javascript">
  function edit_factory(vendor_id)
   {
    // alert(vendor_id);
    $.ajax({
      type:"POST",
      url:"edit/factory_edit.php",
      data:{
        vendor_id:vendor_id
      },
      success:function(data)
      {
        // alert(data);
        $("#total_div").html(data);
      }

    })
  }
</script>
</body>
</html>