<?php
include '../connect.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>kit list</title>
</head>
<body>

  <div class="row" style="*background-image: linear-gradient(180deg, rgb(1, 88, 96,.8), #002437);color: white; height: 42vw;">
    <div class="col-md-3" style="float: right;">
      <form class="navbar-form" role="search">

        <input class="form-control" placeholder="Search" id="kit" type="text" style="background-color: white; margin-top: 1vw; color: black; float: right;">
      </form>
    </div>
    <h3  style="text-align: center;color: black;"><b>CUSTOMER LIST</b></h3>
    <div class="col-lg-12" style="height: 35.85vw; overflow: auto; ">
      <table border="1" class="table" id="kit_table" style="border-width: 2px;font-weight: bold; *background-color:red; color: black;">
        <thead style="*background-color: #008080; color: black;">



          <tr style="font-size: 1vw;">
<th style="width: 5vw;">SL NO:</th>
<th style="text-align: center;">Shop Name </th>
<th style="text-align: center;">Customer Name</th>
<th style="text-align: center;">Customer Address</th>
<th style="text-align: center;">Customer Place</th>
<th style="text-align: center;">Customer Mobile</th>
</tr>

</thead>
<tbody>
  <?php
  $query=mysqli_query($conn,"SELECT * FROM `customers`");
  while($fetch=mysqli_fetch_array($query))
  {
   $customer_id=$fetch["customer_id"];
   $shop_name=$fetch["shop_name"];
   $customer_name=$fetch["customer_name"];
   $customer_address=$fetch["customer_address"];
   $customer_place=$fetch["customer_place"];
   $customer_mobile1=$fetch["customer_mobile1"];
   
   ?>
   <tr>
     <td style="cursor: pointer;" onclick= "edit_customer('<?php echo $customer_id;?>');"> <?php echo $customer_id;?> </td>
     <td style="cursor: pointer;" > <?php echo $shop_name;?> </td>
     <td style="cursor: pointer;"> <?php echo $customer_name;?> </td>
     <td style="cursor: pointer;"> <?php echo $customer_address;?> </td>
     <td style="cursor: pointer;"> <?php echo $customer_place;?> </td>
     <td style="cursor: pointer;"> <?php echo $customer_mobile1;?> </td>
     
   </tr>
    <?php

}
?>
</tbody>
</table>
</div>
</div>

<script type="text/javascript">
  function edit_customer(customer_id)
   {
    // alert(vendor_id);
    $.ajax({
      type:"POST",
      url:"edit/customer_edit.php",
      data:{
        customer_id:customer_id
      },
      success:function(data)
      {
        // alert(data);
        $("#total_div").html(data);
      }

    })
  }
</script>

</body>
</html>