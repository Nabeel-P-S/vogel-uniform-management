<?php
include '../connect.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>kit list</title>
</head>
<body>

  <div class="row" style="*background-image: linear-gradient(180deg, rgb(1, 88, 96,.8), #002437);color: white; height: 42vw;">
    <div class="col-md-3" style="float: right;">
      <form class="navbar-form" role="search">

        <input class="form-control" placeholder="Search" id="kit" type="text" style="background-color: white; margin-top: 1vw; color: black; float: right;">
      </form>
    </div>
    <h3  style="text-align: center;color: black;"><b>ITEM LIST</b></h3>
    <div class="col-lg-12" style="height: 35.85vw; overflow: auto; ">
      <table border="1" class="table" id="kit_table" style="border-width: 2px;font-weight: bold; *background-color:red; color: black;">
        <thead style="*background-color: #008080; color: black;">



          <tr style="font-size: 1vw;">
            <!-- <th rowspan="2" style="width: 5vw;">SL NO:</th> -->
            <th rowspan="2" style="*width: 5vw;">Art NO:</th>
            <th rowspan="2" style="text-align: center;">Item Name</th>
            <th rowspan="2" style="text-align: center;">Item Category</th>
            <th colspan="3" style="text-align: center;">Item Cost</th>
            <!-- <th rowspan="2" style="text-align: center;">Item Image</th> -->

          </tr>

<tr>
  <th>0-12</th>
  <th>12-25</th>
  <th>25- </th>
</tr>
        </thead>
        <tbody>
          <?php
          $query=mysqli_query($conn,"SELECT items.item_id,items.item_name,items.item_no,items.item_image,item_categories.category,items.item_cost1,items.item_cost2,items.item_cost3 FROM `items` LEFT JOIN item_categories ON item_categories.category_id=items.item_category_id");
          while($fetch=mysqli_fetch_array($query))
          {
           $item_id=$fetch["item_id"];
           $item_no=$fetch["item_no"];
           $item_name=$fetch["item_name"];
           $category=$fetch["category"];
           $item_image=$fetch["item_image"];
           $item_cost1=$fetch["item_cost1"];
           $item_cost2=$fetch["item_cost2"];
           $item_cost3=$fetch["item_cost3"];
           
           
           ?>
           <tr>
             <!-- <td style="cursor: pointer;" onclick= "edit_item('<?php echo $item_id;?>');"> <?php echo $item_id;?> </td> -->
             <td style="cursor: pointer;" onclick= "edit_item('<?php echo $item_id;?>');"> <?php echo $item_no;?> </td>
             <td style="cursor: pointer;"> <?php echo $item_name;?>
<!--               <img style="width: 5vw;height: 2vw;" src="item_images/<?php echo $item_image;?>">
 -->               </td>
             <td style="cursor: pointer;"> <?php echo $category;?> </td>
             <td style="cursor: pointer;"> <?php echo $item_cost1;?> </td>
             <td style="cursor: pointer;"> <?php echo $item_cost2;?> </td>
             <td style="cursor: pointer;"> <?php echo $item_cost3;?> </td>


 

          
          
             
           </tr>
           <?php

         }
         ?>
       </tbody>
     </table>
   </div>
 </div>

<script type="text/javascript">
  function edit_item(item_id)
   {
    // alert(vendor_id);
    $.ajax({
      type:"POST",
      url:"edit/item_edit.php",
      data:{
        item_id:item_id
      },
      success:function(data)
      {
        // alert(data);
        $("#total_div").html(data);
      }

    })
  }
</script>
</body>
</html>