<?php
include '../connect.php';
?>
<!DOCTYPE html>
<html>
<head>
  <title>addon list</title>
</head>
<body>

  <div id="addon_list_div" class="row" style="*background-image: linear-gradient(180deg, rgb(1, 88, 96,.8), #002437);color: white; height: 42vw;">
<div class="col-lg-12" >
    <div class="col-md-4" style="float: right;">
      <form class="navbar-form" role="search">
            <input class="form-control" style="*float: right;color: blue; width: 3vw;display: inline;margin-top: 1vw;" type="text" id="vendor_id" onchange="vendor_addon_price(this.value)">

        <input class="form-control" placeholder="Search" id="kit" type="text" style="background-color: white; margin-top: 1vw; color: black; float: right;">

      </form>
    </div>
    <h3  style="text-align: center;color: black;"><b>ADDON LIST</b></h3>
    <div class="col-lg-12" style="height: 35.85vw; overflow: auto; ">
      <table border="1" class="table" id="kit_table" style="border-width: 2px;font-weight: bold; *background-color:red; color: black;">
        <thead style="*background-color: #008080; color: black;">



          <tr  style="font-size: 1vw;">
<th rowspan="2" style="width: 5vw;">SL NO:</th>
<th rowspan="2" style="text-align: center;">Addon Name</th>
<th colspan="3" style="text-align: center;">Addon Vogel Cost</th>
<th  style="text-align: center;">Action</th>

<!-- <th colspan="3" style="text-align: center;">Addon Factory Cost</th> -->

</tr>
<tr>
  <th>1</th>
  <th>2</th>
  <th>3</th>

  
</tr>
</thead>
<tbody>
  <?php
  $query=mysqli_query($conn,"SELECT * FROM `addons`");
  while($fetch=mysqli_fetch_array($query))
  {
   $addon_id=$fetch["addon_id"];
   $addons=$fetch["addon"];
   $addon_price1=$fetch["addon_price1"];
   $addon_price2=$fetch["addon_price2"];
   $addon_price3=$fetch["addon_price3"];
 
  
   ?>
   <tr>
     <td style="cursor: pointer;" onclick= "open_kit_list('<?php echo $kit_id;?>');"> <?php echo $addon_id;?> </td>
    
     <td style="cursor: pointer;"> <?php echo $addons;?>
     
<p style="float: right; display: inline;"> </p>
      </td>
 <td style="cursor: pointer;" > <?php echo $addon_price1;?> </td>
     <td style="cursor: pointer;"> <?php echo $addon_price2;?> </td>
     <td style="cursor: pointer;"> <?php echo $addon_price3;?> </td>
     <td style="cursor: pointer;"> <button class="btn  btn-success active" style="height: 2.5vw;" onclick="edit_addon();"> Edit </button> </td>
     
      <?php 

      $query1=mysqli_query($conn,"SELECT quantity_id,addon_price FROM `addon_price` where addon_id='$addon_id'");
  while($fetch1=mysqli_fetch_array($query1))
   {
    $addon_price=$fetch1["addon_price"];
    ?>
    <td><?php echo $addon_price;?></td> 
    <?php
   }
    ?>

     
    
     
   </tr>
    <?php

}
?>
</tbody>
</table>
</div>
</div>
</div>

<script type="text/javascript">
  function vendor_addon_price(value)
  {
    alert("aaaa");
    var vendor_id=value;
     alert(vendor_id);
 $.ajax(
          {
          type:"POST",
          url:"view/addon_vendor_list.php",
          data:{
            vendor_id:vendor_id
          
          },
          success: function(data_output)
          {
            // alert(data_output);
            $("#addon_list_div").html(data_output);
          }   
        });  
  }
</script>

<script type="text/javascript">
  function edit_addon(addon_id)
   {
    // alert(vendor_id);
    $.ajax({
      type:"POST",
      url:"edit/addon_edit.php",
      data:{
        addon_id:addon_id
      },
      success:function(data)
      {
        // alert(data);
        $("#total_div").html(data);
      }

    })
  }
</script>
</body>
</html>