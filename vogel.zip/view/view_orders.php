<?php
include '../connect.php';
session_start();
 $user_id = $_SESSION["id"];
  $user_name = $_SESSION["username"];
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
  header("location: login.php");
  exit;}
?>
<!DOCTYPE html>
<html>
<head>
    <!-- <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css"> -->
  <title>kit list</title>
  
</head>
<body>

  <div class="row" style="*background-image: linear-gradient(180deg, rgb(1, 88, 96,.8), #002437);color: white; height: 42vw;">
    <div class="col-md-3" style="float: right;">
      <form class="navbar-form" role="search">

        <input class="form-control" placeholder="Search" id="kit" type="text" style="background-color: white; margin-top: 1vw; color: black; float: right;">
      </form>
    </div>
    <h3  style="text-align: center;color: black;"><b>ORDER LIST</b></h3>
    <div class="col-lg-12" style="height: 45vw; overflow: auto; ">
      <table border="1" class="table" id="kit_table" style="border-width: 2px;font-weight: bold; *background-color:red; color: black;">
        <thead style="*background-color: #008080; color: black;">



          <tr style="font-size: 1vw;">
<th style="width: 5vw;">SL NO:</th>

<th style="text-align: center;">Customer Name</th>
<th style="text-align: center;">Item Name</th>
<th style="text-align: center;">Item Quantity</th>
<th style="text-align: center;">Factory Name</th>
<th style="text-align: center;">Delivery Date</th>
<th style="text-align: center;">Status</th>
<!-- <th style="text-align: center;"></th> -->

</tr>

</thead>
<tbody>
  <?php
  $query=mysqli_query($conn,"SELECT orders.order_id,orders.store_delivery_date,orders.status,customers.customer_name,items.item_name,vendors.factory_name,orders.order_quantity from orders LEFT JOIN customers on customers.customer_id=orders.customer_id 
LEFT join items on items.item_id=orders.item_id 
left join vendors on vendors.vendor_id=orders.factory_id ORDER BY   orders.order_id DESC");
  while($fetch=mysqli_fetch_array($query))
  {
   $order_id=$fetch["order_id"];
   $vendor_name=$fetch["factory_name"];
   $customer_name=$fetch["customer_name"];
   
   $store_delivery_date=$fetch["store_delivery_date"];
   $item_name=$fetch["item_name"];
   $order_quantity=$fetch["order_quantity"];
   $status=$fetch["status"];
  
  
   
   ?>
   <tr>
     <td style="cursor: pointer;"data-toggle="modal"  value="preview" data-target="#myModal"> <a href="details/order_view1.php?order_id=<?php echo $order_id;?>"> <?php echo $order_id;?></a> </td>
     <td style="cursor: pointer;" > <?php echo $customer_name;?> </td>
     <td style="cursor: pointer;" onclick= "open_addon_list('<?php echo $order_id;?>');"> <?php echo $item_name;?> </td>
     <td style="cursor: pointer;" onclick= "open_size_list('<?php echo $order_id;?>');">  <?php echo $order_quantity;?> </td>
     <td style="cursor: pointer;"> <?php echo $vendor_name;?> </td>
     <td style="cursor: pointer;"> <?php echo $store_delivery_date;?> </td>
     <td style="cursor: pointer;"> <?php echo $status;?> </td>
                   <!-- <td> 
                     <button type="button"   onclick= "open_order('<?php //echo $order_id;?>');" class="btn btn-warning ">    view</button>
                      <button type="button" onclick= "open_addon_list('<?php //echo $order_id;?>');" class="btn btn-primary ">    addons</button>
                      <button type="button"  onclick= "open_size_list('<?php //echo $order_id;?>');" class="btn btn-info ">    sizes</button>

   </td>
     -->
     
   </tr>
   <tr>
  <td colspan="7" style="padding: 0;">
     <div style="display: none;" id="size_td<?php echo $order_id; ?>">

      <table border="1" class="table" style="background-color:white; color: black;font-weight: bold;">
        <thead style="background-color:#2196F3; font-size:8vw;  color: black;">
   <tr style="font-size: 1vw;">
           <th >SL NO:</th>
           <th style="text-align: center;"> Sizes </th>
            <th style="text-align: center;">Size Quantity</th>

          </tr>
        </thead>
        <?php
        $query2=mysqli_query($conn,"SELECT order_quantity.id, order_quantity.order_id,order_quantity.order_quantity, order_quantity.size_id,sizes.size FROM `order_quantity`
left join `sizes` on sizes.size_id=order_quantity.size_id  WHERE order_id='$order_id'");
        $sleno=1;
        while ($fetch2=mysqli_fetch_array($query2))
         {
          $id=$fetch2['id'];
          
       
$size=$fetch2['size'];
$order_quantity=$fetch2['order_quantity'];

      
        ?>
        <tr>

          <td> <?php echo $sleno; ?></td>
          <td> <?php echo $size; ?></td>
          <td> <?php echo $order_quantity; ?></td>
          
            
      </tr>





<?php
$sleno++;
  }
    ?>
  </table>
      </div>
    </td>
  </tr>

  <tr>
  <td colspan="7" style="padding: 0;">
     <div style="display: none;" id="addon_td<?php echo $order_id; ?>">

      <table border="1" class="table" style="background-color:white; color: black;font-weight: bold;">
        <thead style="background-color:pink; font-size:8vw;  color: black;">
   <tr style="font-size: 1vw;">
           <th >SL NO:</th>
           <th style="text-align: center;">
           ADDONS 
            </th>
            <!-- <th style="text-align: center;">item Quantity</th> -->

          </tr>
        </thead>
        <?php
        $query1=mysqli_query($conn,"SELECT order_addons.id, order_addons.order_id, order_addons.addon_id,addons.addon FROM `order_addons`
        left join `addons` on addons.addon_id=order_addons.addon_id  WHERE order_id='$order_id'");
        $sleno=1;
        while ($fetch1=mysqli_fetch_array($query1))
         {
          $id=$fetch1['id'];
          
       
$addon=$fetch1['addon'];

      
        ?>
        <tr>

          <td> <?php echo $sleno; ?></td>
          <td> <?php echo $addon; ?></td>
          
            
      </tr>

<?php
$sleno++;
  }
    ?>
  </table>
      </div>
    </td>
  </tr>
    <?php

}
?>
</tbody>
</table>
</div>
</div>

                  
  <script type="text/javascript">
                    function open_order(order_id)
                    {
                      if ("<?php echo $user_name; ?>" != "admin")
                      {
                        swal("NO ACESS","Contact Admin ","error");
                      }
                      else
                      {

              $.ajax(
              {
                type:"POST",
                // dataType:"json",
                url:"details/order_view.php",
                // url:"details/details_box.php",
                data:{
                  order_id:order_id
                   
                    },
                  
                success:function(data)
                {
                  // alert(data);
// document.getElementById("full_div").style.border=red;
                  // $("#full_div").html(data);
                  $("#total_div").html(data);

                }
              })
                      }
                      // alert(order_id);
     // document.getElementById('buyer_modal').style.display = "block";
// alert("opening order");
           
           
                      

                    }

                  </script>
                  
</body>
    
    <script>
    function open_addon_list(order_id)
  {

if (document.getElementById("addon_td"+order_id).style.display=="block")
{
  document.getElementById("addon_td"+order_id).style.display="none";
  }
  else
  {
   document.getElementById("addon_td"+order_id).style.display="block"; 
  }
}
</script>
<script>
    function open_size_list(order_id)
  {

if (document.getElementById("size_td"+order_id).style.display=="block")
{
  document.getElementById("size_td"+order_id).style.display="none";
  }
  else
  {
   document.getElementById("size_td"+order_id).style.display="block"; 
  }
}
</script>
</html>

