<?php
include "../connect.php";
	$customer_id=$_POST['customer_id'];
 echo "$customer_id";
	$image=$_FILES["customer_image_id"]["name"];
	  echo $image;
	
$filetmp=$_FILES["customer_image_id"]["tmp_name"];
$extension=pathinfo($image,PATHINFO_EXTENSION);
$image_nw=str_replace(".".$extension,"", $image);
	date_default_timezone_set('Asia/Calcutta');
	if ($image_nw!="")
	 {
		
	
	$newfilename=$image_nw .'_'.date('Y-m-d h-i-s').".".$extension;
 $newfilename;

echo $filepath = "../customer_images/".$newfilename;

move_uploaded_file($filetmp,$filepath);


 $query=mysqli_query($conn,"UPDATE `customers` SET `customer_image`='$newfilename' WHERE `customer_id`='$customer_id'");
 echo $filepath;
 }
// $personal_info= $conn->insert_id;
// echo json_encode(array("personal_info"=>$personal_info));
 // echo "photo updated";
?>

