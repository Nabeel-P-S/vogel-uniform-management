-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 08, 2019 at 03:17 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `avogel`
--

-- --------------------------------------------------------

--
-- Table structure for table `addons`
--

CREATE TABLE `addons` (
  `addon_id` int(11) NOT NULL,
  `addon` varchar(250) NOT NULL,
  `addon_price1` varchar(250) NOT NULL,
  `addon_price2` varchar(250) NOT NULL,
  `addon_price3` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addons`
--

INSERT INTO `addons` (`addon_id`, `addon`, `addon_price1`, `addon_price2`, `addon_price3`) VALUES
(1, 'chest logo', '3', '2', '1'),
(2, 'neck logo 3 mm ', '8', '5', '4');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `shop_name` varchar(250) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `customer_address` varchar(250) NOT NULL,
  `customer_place` varchar(250) NOT NULL,
  `customer_pincode` varchar(250) NOT NULL,
  `customer_district` varchar(250) NOT NULL,
  `customer_state` varchar(250) NOT NULL,
  `customer_country` varchar(250) NOT NULL,
  `customer_email` varchar(200) NOT NULL,
  `customer_mobile1` varchar(200) NOT NULL,
  `customer_mobile2` varchar(200) NOT NULL,
  `customer_adhar` varchar(250) NOT NULL,
  `customer_license` varchar(250) NOT NULL,
  `customer_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `shop_name`, `customer_name`, `customer_address`, `customer_place`, `customer_pincode`, `customer_district`, `customer_state`, `customer_country`, `customer_email`, `customer_mobile1`, `customer_mobile2`, `customer_adhar`, `customer_license`, `customer_status`) VALUES
(1, 'black bird', 'arshad p i', 'kunnamkulam nerar bus stand', 'km', '2343', 'thrissur', 'sss', '', 'a@gmail.coms', '11111111', '11111111', '11111111', '111111111', 1),
(2, 'nabeel', 'wfw', 'ewe', 'e', '33', 'Wayanad', 'Meghalaya', '', '333', '2222', '2222', '2222', '2222', 1),
(3, 'colofrul', 'colofrul', 'colofrul', 'colofrul', '6546', 'Kannur', 'Meghalaya', '', 'colofrul', '111111', '111111111111', '1111111111111', '111111111111', 1),
(4, 'colofrulSS', 'colofrulSS', 'colofrulSS', 'colofrulS', '65468', 'KannurS', 'MeghalayaS', '', 'colofrulSS', '111111SS', '111111111111SS', '1111111111111S', '111111111111S', 1),
(5, 'colofrulSSaaaa', 'colofrulSS', 'colofrulSS', 'colofrulS', '65468', 'KannurS', 'MeghalayaS', '', 'colofrulSS', '111111SS', '111111111111SS', '1111111111111S', '111111111111S', 1),
(6, 'nissaram shop', 'Nabeel Shamsu', 'puth', 'choondal', '680504', 'thrissur', 'kerala', '', 'nabeelcm1@gmail.com', '7736656121', '8089544029', '346676099016', '56-98746/1237', 1),
(7, 'fafa fashions', 'sasi', 'abc villa', 'aluva', '4856859', 'Kottayam', 'Kerala', '', 'edrftgtf@gmail.com', '3456', '5566', '666', '45566', 1);

-- --------------------------------------------------------

--
-- Table structure for table `fabric`
--

CREATE TABLE `fabric` (
  `fabric_id` int(11) NOT NULL,
  `fabric` varchar(250) NOT NULL,
  `fabric_price` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fabric`
--

INSERT INTO `fabric` (`fabric_id`, `fabric`, `fabric_price`) VALUES
(1, 'cotton', '56'),
(2, 'jutesss', '654'),
(3, 'nirmal nut', '20'),
(4, 's', '50'),
(5, 'uuu', '44'),
(6, '44', '44'),
(7, '44', '44'),
(8, '77', '77'),
(9, '777', '7777'),
(10, '777', '777'),
(11, '777', '777');

-- --------------------------------------------------------

--
-- Table structure for table `factory_addon_price`
--

CREATE TABLE `factory_addon_price` (
  `factory_addon_cost_id` int(11) NOT NULL,
  `addon_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `factory_addon_price1` varchar(250) NOT NULL,
  `factory_addon_price2` varchar(250) NOT NULL,
  `factory_addon_price3` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `factory_cost`
--

CREATE TABLE `factory_cost` (
  `factory_item_cost_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `factory_item_cost1` varchar(250) NOT NULL,
  `factory_item_cost2` varchar(250) NOT NULL,
  `factory_item_cost3` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `factory_fabric_price`
--

CREATE TABLE `factory_fabric_price` (
  `id` int(11) NOT NULL,
  `fabric_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `factory_fabric_price` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factory_fabric_price`
--

INSERT INTO `factory_fabric_price` (`id`, `fabric_id`, `vendor_id`, `factory_fabric_price`) VALUES
(1, 1, 1, 2),
(2, 2, 1, 2),
(3, 1, 2, 2),
(4, 2, 2, 2),
(5, 1, 3, 2),
(6, 2, 3, 2);

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_no` int(11) NOT NULL,
  `item_name` varchar(250) NOT NULL,
  `item_category_id` int(11) NOT NULL,
  `item_image` varchar(500) NOT NULL,
  `item_cost1` varchar(250) NOT NULL,
  `item_cost2` varchar(250) NOT NULL,
  `item_cost3` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_no`, `item_name`, `item_category_id`, `item_image`, `item_cost1`, `item_cost2`, `item_cost3`) VALUES
(1, 1, 'oneman', 6, '14_2019-09-28 01-23-15.jpg', '222', '2222', '2222'),
(2, 1, 'mund', 3, '', '30', '20', '10'),
(3, 3, 'mund', 4, 'download_2019-09-16 01-37-10_2019-09-17 09-49-49.jpg', '30', '20', '10'),
(4, 4, 'kkkkkkk', 4, '19_2019-09-28 01-23-34.jpg', '44', '44', '44'),
(5, 5, 'sss', 0, '', '22', '33', '55'),
(6, 6, 'items samples', 3, '4_2019-09-22 10-49-08.jpg', '25', '20', '18'),
(7, 7, 'muharam', 5, 'ProfitLoss_2019-09-28 01-15-51.png', '56', '54', '52'),
(8, 8, 'v neck body half front and back half sublimation', 7, '', '400', '380', '350');

-- --------------------------------------------------------

--
-- Table structure for table `item_categories`
--

CREATE TABLE `item_categories` (
  `category_id` int(11) NOT NULL,
  `category` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_categories`
--

INSERT INTO `item_categories` (`category_id`, `category`) VALUES
(1, 'School Uniform'),
(2, 'Office Uniform'),
(3, 'Casual Dress'),
(4, 'Restarunt Uniform ddd'),
(5, 'Perunnal dress'),
(6, 'Festival dress wwww'),
(7, 'foot ball jersey ');

-- --------------------------------------------------------

--
-- Table structure for table `item_quantity`
--

CREATE TABLE `item_quantity` (
  `quantity_id` int(11) NOT NULL,
  `quantity_details` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `old_orders`
--

CREATE TABLE `old_orders` (
  `id` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_category_id` int(11) NOT NULL,
  `order_unit_id` int(11) NOT NULL,
  `order_quantity` varchar(250) NOT NULL,
  `order_customer_id` int(11) NOT NULL,
  `odrer_confirm_date` datetime NOT NULL,
  `order_send_date` date NOT NULL,
  `order_set_date` datetime NOT NULL,
  `order_recieve_date` datetime NOT NULL,
  `order_dispatch_date` date NOT NULL,
  `amount` varchar(250) NOT NULL,
  `charge1` varchar(200) NOT NULL,
  `charge2` varchar(200) NOT NULL,
  `charge3` varchar(250) NOT NULL,
  `charge4` varchar(250) NOT NULL,
  `charge5` varchar(250) NOT NULL,
  `discount` varchar(250) NOT NULL,
  `total` varchar(250) NOT NULL,
  `advance` varchar(250) NOT NULL,
  `balance` varchar(250) NOT NULL,
  `advance_status` int(11) NOT NULL,
  `production_status` int(11) NOT NULL,
  `fabric_status` int(11) NOT NULL,
  `stitch_status` int(11) NOT NULL,
  `pack_status` int(11) NOT NULL,
  `resend_status` int(11) NOT NULL,
  `dispatch_status` int(11) NOT NULL DEFAULT '0',
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `payment_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL,
  `delivery_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `order_quantity` varchar(250) NOT NULL,
  `factory_id` int(11) NOT NULL,
  `order_item_cost` varchar(250) NOT NULL,
  `order_addon_cost` varchar(250) NOT NULL,
  `order_total_cost` varchar(250) NOT NULL,
  `order_factory_item_cost` varchar(250) NOT NULL,
  `order_factory_addon_cost` varchar(250) NOT NULL,
  `order_factory_total_cost` varchar(250) NOT NULL,
  `advance_amount` varchar(250) NOT NULL,
  `advance_status` int(11) NOT NULL DEFAULT '0',
  `production_status` int(11) NOT NULL DEFAULT '0',
  `fabric_status` int(11) NOT NULL DEFAULT '0',
  `stitch_status` int(11) NOT NULL DEFAULT '0',
  `pack_status` int(11) NOT NULL DEFAULT '0',
  `store_status` int(11) NOT NULL DEFAULT '0',
  `dispatch_status` int(11) NOT NULL DEFAULT '0',
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `payment_status` int(11) NOT NULL DEFAULT '0',
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `delivery_date`, `customer_id`, `item_id`, `order_quantity`, `factory_id`, `order_item_cost`, `order_addon_cost`, `order_total_cost`, `order_factory_item_cost`, `order_factory_addon_cost`, `order_factory_total_cost`, `advance_amount`, `advance_status`, `production_status`, `fabric_status`, `stitch_status`, `pack_status`, `store_status`, `dispatch_status`, `delivery_status`, `payment_status`, `status`) VALUES
(1, '2019-09-14 11:07:19', '2019-09-11', 1, 1, '40', 1, '', '', '400', '', '', '200', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 'Production Started'),
(2, '2019-09-15 11:27:18', '0000-00-00', 0, 0, '', 0, '', '', '', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(3, '2019-09-16 01:33:34', '2019-09-19', 1, 3, '34', 2, '', '', '340', '', '', '0', '', 0, 1, 1, 0, 0, 0, 0, 0, 0, 'Store Reached'),
(4, '2019-09-16 01:47:13', '2019-09-12', 1, 5, '28', 2, '', '', '84', '', '', '0', '', 1, 0, 0, 0, 0, 0, 0, 0, 0, 'Advance Paid'),
(5, '2019-09-22 03:08:40', '2019-08-23', 1, 6, '11', 3, '', '', '0', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(6, '2019-09-22 03:11:44', '2019-08-23', 2, 6, '23', 3, '', '', '0', '', '', '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(7, '2019-09-22 03:18:05', '2019-08-23', 2, 3, '15', 3, '', '', '0', '', '', '0', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(8, '2019-09-22 03:24:24', '2019-08-23', 2, 6, '16', 3, '', '', '400', '', '', '160', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(9, '2019-09-23 11:05:09', '2019-08-24', 2, 6, '10', 3, '250', '30', '280', '100', '30', '130', 'advance_amount', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(10, '2019-09-23 11:12:45', '2019-10-08', 2, 6, '10', 3, '250', '30', '280', '120', '30', '150', '50', 1, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(11, '2019-09-23 04:23:15', '2019-10-08', 3, 7, '10', 5, '500', '110', '610', '300', '250', '550', '500', 1, 1, 1, 1, 1, 0, 0, 0, 0, 'Store Reached'),
(12, '2019-09-27 08:33:24', '2019-10-12', 2, 1, '65', 3, '650', '260', '910', '195', '65', '260', '100', 1, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(13, '2019-09-27 08:35:11', '2019-10-12', 1, 6, '143', 3, '2574', '715', '3289', '572', '286', '858', '500', 1, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(14, '2019-09-27 08:35:48', '2019-10-12', 3, 2, '22', 2, '440', '44', '484', '22', '22', '44', '50', 1, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(15, '2019-09-27 08:36:10', '2019-10-12', 3, 2, '22', 2, '440', '44', '484', '22', '22', '44', '50', 1, 0, 0, 0, 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Table structure for table `order_addons`
--

CREATE TABLE `order_addons` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `addon_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_addons`
--

INSERT INTO `order_addons` (`id`, `order_id`, `addon_id`) VALUES
(1, 1, 1),
(2, 3, 2),
(3, 3, 3),
(4, 4, 2),
(5, 5, 2),
(6, 6, 2),
(7, 7, 2),
(8, 8, 2),
(9, 0, 1),
(10, 9, 1),
(11, 10, 1),
(12, 10, 2),
(13, 10, 1),
(14, 11, 1),
(15, 11, 2),
(16, 12, 2),
(17, 13, 2),
(18, 13, 1),
(19, 14, 1),
(20, 15, 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_quantity`
--

CREATE TABLE `order_quantity` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `order_quantity` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_quantity`
--

INSERT INTO `order_quantity` (`id`, `order_id`, `size_id`, `order_quantity`) VALUES
(1, 1, 1, '5'),
(2, 1, 2, '5'),
(3, 1, 3, '5'),
(4, 1, 4, '5'),
(5, 1, 5, '5'),
(6, 1, 6, '5'),
(7, 1, 7, '5'),
(8, 1, 8, '5'),
(9, 3, 1, '5'),
(10, 3, 2, '3'),
(11, 3, 3, '9'),
(12, 3, 4, '5'),
(13, 3, 5, '2'),
(14, 3, 6, '1'),
(15, 3, 7, '3'),
(16, 3, 8, '6'),
(17, 4, 1, '6'),
(18, 4, 2, '6'),
(19, 4, 3, '3'),
(20, 4, 4, '2'),
(21, 4, 5, '6'),
(22, 4, 7, '2'),
(23, 4, 8, '3'),
(24, 5, 1, '11'),
(25, 6, 1, '2'),
(26, 6, 2, '5'),
(27, 6, 3, '4'),
(28, 6, 4, '1'),
(29, 6, 5, '2'),
(30, 6, 6, '6'),
(31, 6, 7, '2'),
(32, 6, 8, '1'),
(33, 7, 1, '15'),
(34, 8, 1, '2'),
(35, 8, 5, '9'),
(36, 8, 7, '5'),
(37, 0, 1, '11'),
(38, 9, 1, '10'),
(39, 10, 1, '10'),
(40, 11, 1, '10'),
(41, 12, 1, '6'),
(42, 12, 2, '55'),
(43, 12, 3, '4'),
(44, 13, 1, '2'),
(45, 13, 2, '65'),
(46, 13, 3, '41'),
(47, 13, 4, '35'),
(48, 14, 1, '22'),
(49, 15, 1, '22');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `size_id` int(11) NOT NULL,
  `size` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`size_id`, `size`) VALUES
(1, 'XXS'),
(2, 'XS'),
(3, 'S'),
(4, 'M'),
(5, 'L'),
(6, 'XL'),
(7, 'XXL'),
(8, 'XXXL');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `status`) VALUES
(1, 'nabeel', '$2y$10$551WmOf/JskxE7jkeEGTbOC/3bUdikrV0Cn10jsbI990vxMfd5jQ2', '2019-09-12 09:45:31', 0),
(2, 'vogel', '$2y$10$Ttcfkmo1kWGymCLN6KfMuOJoPwFokknGWoZvpVqqUbwwSEUN0lAIK', '2019-09-16 18:01:56', 0),
(3, 'admin', '$2y$10$GCj77JGGYiDFf2XxuG0TEe3etzX79HW4W766JmqrNMEw0cVGMgaKS', '2019-09-16 20:13:28', 1),
(4, 'user', '$2y$10$D/QDP5PSrtIx5vwDngMZx.YkII0g6FPluy0hgTQeXqJara/SOIG9S', '2019-09-20 16:08:37', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `vendor_id` int(11) NOT NULL,
  `factory_name` varchar(250) NOT NULL,
  `vendor_name` varchar(250) NOT NULL,
  `vendor_address` varchar(250) NOT NULL,
  `vendor_place` varchar(250) NOT NULL,
  `vendor_district` varchar(250) NOT NULL,
  `vendor_state` varchar(250) NOT NULL DEFAULT 'Kerala',
  `vendor_pincode` varchar(250) NOT NULL,
  `vendor_email` varchar(250) NOT NULL,
  `vendor_mobile1` varchar(200) NOT NULL,
  `vendor_mobile2` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`vendor_id`, `factory_name`, `vendor_name`, `vendor_address`, `vendor_place`, `vendor_district`, `vendor_state`, `vendor_pincode`, `vendor_email`, `vendor_mobile1`, `vendor_mobile2`) VALUES
(1, '', '', '', '', 'Select district', 'Kerala', '', '', '', ''),
(2, '', '', '', '', 'Select district', 'Kerala', '', '', '', ''),
(3, '', '', '', '', 'Select district', 'Kerala', '', '', '', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addons`
--
ALTER TABLE `addons`
  ADD PRIMARY KEY (`addon_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `fabric`
--
ALTER TABLE `fabric`
  ADD PRIMARY KEY (`fabric_id`);

--
-- Indexes for table `factory_addon_price`
--
ALTER TABLE `factory_addon_price`
  ADD PRIMARY KEY (`factory_addon_cost_id`);

--
-- Indexes for table `factory_cost`
--
ALTER TABLE `factory_cost`
  ADD PRIMARY KEY (`factory_item_cost_id`);

--
-- Indexes for table `factory_fabric_price`
--
ALTER TABLE `factory_fabric_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `item_categories`
--
ALTER TABLE `item_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `item_quantity`
--
ALTER TABLE `item_quantity`
  ADD PRIMARY KEY (`quantity_id`);

--
-- Indexes for table `old_orders`
--
ALTER TABLE `old_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_addons`
--
ALTER TABLE `order_addons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_quantity`
--
ALTER TABLE `order_quantity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`size_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addons`
--
ALTER TABLE `addons`
  MODIFY `addon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `fabric`
--
ALTER TABLE `fabric`
  MODIFY `fabric_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `factory_addon_price`
--
ALTER TABLE `factory_addon_price`
  MODIFY `factory_addon_cost_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `factory_cost`
--
ALTER TABLE `factory_cost`
  MODIFY `factory_item_cost_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `factory_fabric_price`
--
ALTER TABLE `factory_fabric_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `item_categories`
--
ALTER TABLE `item_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `item_quantity`
--
ALTER TABLE `item_quantity`
  MODIFY `quantity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `old_orders`
--
ALTER TABLE `old_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `order_addons`
--
ALTER TABLE `order_addons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT for table `order_quantity`
--
ALTER TABLE `order_quantity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
