<!DOCTYPE html>
<html>
<head>
	<title>search</title>
</head>
<body>

<form class="form-horizontal">
<fieldset>

<!-- Form Name -->
<br><br>
<legend>Search Order Deails</legend>

<!-- Text input-->
<div class="form-group">
  <label class="col-md-4 control-label" for="refernce_no">Order Ref No</label>  
  <div class="col-md-5">
  <input id="reference_no" name="refernce_no" type="text" placeholder="Refernce no" class="form-control input-md">
    
  </div>
</div>

<!-- Button -->
<div class="form-group">
  <label class="col-md-4 control-label" for=""></label>
  <div class="col-md-4">
    <button id="" name="" onclick="search_order1();" class="btn btn-success">serch</button>
  </div>
</div>

</fieldset>
</form>

</body>
<script type="text/javascript">
	function search_order1()
	{
		var reference_no=document.getElementById("reference_no").value;
		// alert(reference_no);


            $.ajax(
            {
              type:"POST",
              url:"ref_no.php",
              data:{
                reference_no:reference_no
                
              },
              success: function(data_output)
              {
                // $("#display_div").html(data_output);
                $("#total_div").html(data_output);


              }   
            });  
          }
</script>
	
</html>