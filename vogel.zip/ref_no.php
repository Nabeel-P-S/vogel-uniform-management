<!DOCTYPE html>
<html>
<head>
  
	<title></title>
</head>
<body>
<?php
include"connect.php";
$reference_no=$_POST["reference_no"];
$sql="SELECT * from orders where reference_no=$reference_no";
// echo $sql;
$query=mysqli_query($conn,$sql);
$fetch=mysqli_fetch_array($query);
$order_id=$fetch["order_id"];
$agent_id=$fetch["customer_id"];
$store_delivery_date=$fetch["store_delivery_date"];
$main_delivery_date=$fetch["main_delivery_date"];
$order_quantity=$fetch["order_quantity"];
$order_date=$fetch["order_date"];
?>
<style >
	td
	{
		padding: .5vw;
	}
</style>
<div onclick="a();">
<table  border="1" style="margin-top: 5vw;">
	<tr><td colspan="2"><p> ORDER ID=<?php echo $order_id; ?></p></td>
		
	</tr>
	<tr><td>Order Date </td><td> <?php echo $order_date; ?></td> </tr>
	<tr><td>Agent </td><td> <?php echo $agent_id; ?></td> </tr>
	<tr><td>Store Delivery Date </td><td> <?php echo $store_delivery_date; ?></td> </tr>
	<tr><td>Main Delivery Date</td><td> <?php echo $main_delivery_date; ?></td> </tr>
	<tr><td> Total Quantity</td><td> <?php echo $order_quantity; ?></td> </tr>
</table>
</div>
</body>
<script type="text/javascript">
	function a() {
		alert("succes");
	}
</script>
</html>