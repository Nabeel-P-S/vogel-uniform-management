<?php
include("../connect.php");

if (isset($_GET['order_id']))
{
  $order_id=$_GET['order_id'];

}
else
{
  $order_id=$_POST['order_id'];
}
include("order_complete.php");


// include("../view/view_orders.php");




?>

<html>
<script type="text/javascript">
  // function view_image()
  // {
  //   document.getElementById("image_preview").src= URL.createObjectURL(event.target.files[0]);
  // }
</script>
<style type="text/css">
  body
  {
    
   font-family: "Poppins", sans-serif !important;
   color: black;
 }
 td
 {
  font-size: 1.1vw;
  color: black;
 }

</style>

<head>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins">

  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>

  <title>Application Preview</title>

</head>
<body>
	

  <div class="container-fluid" > 
    <div class="col-lg-3">
      <table border="1" class="table" >
    <thead>
     <tr >

       <th style="text-align: center;">Customer  Image </th>
       <!-- <th style="text-align: center;"><?php echo $factory_name ?></th> -->
       <tr>
        <td ><div style="text-align: center;"><img width="150" src="../customer_images/<?php echo $customer_image; ?>"></div></td>
      </tr>
    </thead>

    <tr></tr></table>
    </div>
    <div class="col-lg-6"style="border: 3px solid #00549A;padding-left: 0;
    padding-right: 0;padding-bottom: 0vw;">
      <table class="table table-striped table-bordered table-hover" >
<tr><td colspan="2"><h3  style="text-align: center;color: black;"><b><?php echo $order_id." "."-"." ".$shop_name; ?></b></h3></td></tr>
        <tr><td>Reference No</td><td><?php echo $reference_no; ?></td></tr>
   <tr>
          <td> Order Date</td>
          <td> <?php echo $order_date; ?></td>           
        </tr>
        <tr>
          <td> Delivery Date</td>
          
          <td> <?php echo $store_delivery_date; ?></td>           
        </tr>
        <tr>
           <tr>
          <td> Main Delivery Date</td>
          <td> <?php echo $main_delivery_date; ?></td>           
        </tr>
        <tr><td colspan="2"><a href="order_print.php?order_id=<?php echo $order_id;?>"><button class="btn  btn-primary active" style="height: 2.5vw;"> Print Purchase Order</button></a>
          <a href="order_store_print.php?order_id=<?php echo $order_id;?>"><button class="btn  btn-success active" style="height: 2.5vw;"> Print Store Bill</button></a>
 <a href="order_delivery_print.php?order_id=<?php echo $order_id;?>"><button class="btn  btn-warning active" style="height: 2.5vw;"> Print Delivery Sheet</button>
  <a href="order_bundle_print.php?order_id=<?php echo $order_id;?>"><button class="btn  btn-danger" style="height: 2.5vw;"> Print Bundle Print</button></a></a>
        </td></tr>
      </table>
      

    </div>
    <div class="col-lg-3"><table border="1" class="table" >
    <thead>
     <tr >

       <th style="text-align: center;">Item Image </th>
       <!-- <th style="text-align: center;"><?php echo $factory_name ?></th> -->
       <tr>
        <td ><div style="text-align: center;"><img width="150" src="../item_images/<?php echo $item_image; ?>"></div></td>
      </tr>

    </thead>

    <tr></tr></table></div>
  </div>
  <div class="container-fluid" > 
    <div class="col-lg-4">
      <h4  ><b>CUSTOMER</b></h4>
      <table border="1" class="table table-striped table-bordered table-hover" >
        <thead >
          <tr >
            <th> Shop Name </th>
            <th><?php echo $shop_name ?></th>
          </tr>
        </thead>
        <tr>
          <td> Customer</td>
          <td> <?php echo $customer_name; ?></td>           
        </tr>
        <tr>
          <td> Customer Address</td>
          <td> <?php echo $customer_address; ?></td>           
        </tr>
        <tr>
          <td> Customer Place</td>
          <td> <?php echo $customer_place; ?></td>           
        </tr>
        <tr>
          <td> District</td>
          <td> <?php echo $customer_district; ?></td>           
        </tr>
        <tr>
          <td>  Mobile 1</td>
          <td> <?php echo $customer_mobile1; ?></td>           
        </tr>
        <tr>
          <td>  Mobile 2</td>
          <td> <?php echo $customer_mobile2; ?></td>           
        </tr>
        <tr>
          <td> Customer Adhar</td>
          <td> <?php echo $customer_adhar; ?></td>           
        </tr>
        <tr>
          <td>  License No</td>
          <td> <?php echo $customer_license; ?></td>           
        </tr>
     </table>
    </div>


    <div class="col-lg-4">
      <h4  ><b>FACTORY</b></h4>
      <table border="1" class="table table-striped table-bordered table-hover" >
        <thead >
          <tr >
            <th > Factory Name </th>
            <th ><?php echo $factory_name ?></th>
          </tr>
        </thead>
        <tr>
          <td> Factory</td>
          <td> <?php echo $vendor_name; ?></td>           
        </tr>
        <tr>
          <td> Factory Address</td>
          <td> <?php echo $vendor_address; ?></td>           
        </tr>
        <tr>
          <td> Factory Place</td>
          <td> <?php echo $vendor_place; ?></td>           
        </tr>
        <tr>
          <td> Factory District</td>
          <td> <?php echo $vendor_district; ?></td>           
        </tr>
        <tr>
          <td> Factory Mobile 1</td>
          <td> <?php echo $vendor_mobile1; ?></td>           
        </tr>
        <tr>
          <td> Factory Mobile2</td>
          <td> <?php echo $vendor_mobile2; ?></td>           
        </tr>
        <tr>
          <td> Customer Adhar</td>
          <td> <?php echo $customer_adhar; ?></td>           
        </tr>
        <tr>
          <td> Customer License</td>
          <td> <?php echo $customer_license; ?></td>           
        </tr>
     </table>
    </div>

    <div class="col-lg-3">
      <h4  ><b>ITEM</b></h4>

      <table border="1" class="table table-striped table-bordered table-hover" >
        <thead >
          <tr>
            <th > Item</th>
            <th ><?php echo $item_name ?></th>
          </tr>
        </thead>
        <tr>
          <td> Art No </td>
          <td> <?php echo $item_no; ?></td>           
        </tr>
        <tr>
          <td> Quantity </td>
          <td> <?php echo $order_quantity; ?></td>           
        </tr>
           <tr>
          <td> Fabric</td>
          <td> <?php echo $fabric; ?></td>           
        </tr>
        <tr>
     
          <td> Category</td>
          <td> <?php echo $category; ?></td>           
        </tr>
        <tr>
          <td> Order Cost</td>
          <td> <?php echo $order_total_cost; ?></td>           
        </tr>

     </table>
    </div>

</div>


<div class="container-fluid">
  <div class="col-lg-3">
    <h4  ><b>ADDONS</b></h4>
    <table  border="1" class="table" >
      <thead >
       <tr>
        <th >SL NO:</th>
         <th >
           ADDONS 
         </th>
         <!-- <th style="text-align: center;">item Quantity</th> -->

       </tr>
     </thead>
     <?php
     $query1=mysqli_query($conn,"SELECT order_addons.id, order_addons.order_id, order_addons.addon_id,addons.addon FROM `order_addons`
      left join `addons` on addons.addon_id=order_addons.addon_id  WHERE order_id='$order_id'");
     $sleno=1;
     while ($fetch1=mysqli_fetch_array($query1))
     {

      $id=$fetch1['id'];


      $addon=$fetch1['addon'];

      
      ?>
      <tr>

        <td> <?php echo $sleno; ?></td>
        <td> <?php echo $addon; ?></td>


      </tr>

      <?php
      $sleno++;
    }
    ?>
  </table> 
</div>
<div class="col-lg-3">
  <h4 ><b>SIZES</b></h4>

  <table border="1" class="table" >
    <thead >
     <tr >
       <th >SL NO:</th>
       <th > Sizes </th>
       <th >Size Quantity</th>

     </tr>
   </thead>
   <?php
   $query2=mysqli_query($conn,"SELECT order_quantity.id, order_quantity.order_id,order_quantity.order_quantity, order_quantity.size_id,sizes.size FROM `order_quantity`
    left join `sizes` on sizes.size_id=order_quantity.size_id  WHERE order_id='$order_id'");
   $sleno=1;
   while ($fetch2=mysqli_fetch_array($query2))
   {
    $id=$fetch2['id'];


    $size=$fetch2['size'];
    $order_quantity=$fetch2['order_quantity'];


    ?>
    <tr>

      <td> <?php echo $sleno; ?></td>
      <td> <?php echo $size; ?></td>
      <td> <?php echo $order_quantity; ?></td>


    </tr>





    <?php
    $sleno++;
  }
  ?>
</table>
</div>







    <div class="col-lg-3">
      <h4  ><b>AMOUNT</b></h4>
      <table border="1" class="table table-striped table-bordered table-hover" >
        <thead >
          <tr >
            <th > Order Total Cost</th>
            <th ><?php echo $order_total_cost ?></th>
          </tr>
        </thead>
        <tr>
          <td> Fabric Cost</td>
          <td> <?php echo $order_fabric_cost; ?></td>           
        </tr>
        <tr>
          <td>Addon Cost</td>
          <td> <?php echo $order_addon_cost; ?></td>           
        </tr>
        <tr>
          <td> Item Cost</td>
          <td> <?php echo $order_item_cost; ?></td>           
        </tr>
      
     </table>
    </div>
        <div class="col-lg-3">
      <h4  ><b>FACTORY AMOUNT</b></h4>
      <table border="1" class="table table-striped table-bordered table-hover" >
        <thead >
          <tr >
            <th > Order Total Cost</th>
            <th ><?php echo $order_factory_total_cost ?></th>
          </tr>
        </thead>
        <tr>
          <td> Fabric Cost</td>
          <td> <?php echo $order_factory_fabric_cost; ?></td>           
        </tr>
        <tr>
          <td>Addon Cost</td>
          <td> <?php echo $order_factory_addon_cost; ?></td>           
        </tr>
        <tr>
          <td> Item Cost</td>
          <td> <?php echo $order_factory_item_cost; ?></td>           
        </tr>
      
     </table>
    </div>
  </div>
<a href="order_view.php?order_id=<?php echo $order_id;?>">Order View</a>
<!-- <a href="details/order_view1.php?order_id=<?php echo $order_id;?>"> <?php echo $order_id;?></a> -->

 <!-- <div style="height: 3vw; padding-top: 1vw;"> 
 	 <input type="button"class =button_css id="fee_save" name="fee_save" onclick="save_application_form()"  value="save"style="width: 7vw;background-color:#133d47;margin-left: 34vw; color:white  ;font-weight: bold; padding: .3vw;font-size: 1.2vw;border-color: white;float: left;">
 	
 	
          <button type="button" class="btn btn-default" style="width: 7vw;background-color:#133d47;margin-left: 3vw; color:white  ;font-weight: bold; padding: .3vw;font-size: 1.2vw;border-color: white;display: inline;" data-dismiss="modal">Edit</button>
        </div> -->

      </body>
      </html>

