<?php
 $order_id=$_GET['order_id'];
include("../connect.php");
include("order_complete.php");
?>
<head>
    <script type="text/javascript">
        // window.onload=window.print();
    </script>
    <style type="text/css">

        #printable { display: block; }

        @media print
        {
            #non-printable { display: none; }
            #printable { 
                display: block; 
                font-size: 4vw;
                /*background-color: pink;*/
            }
        }

        table
        {
            border: 1.5px solid black;
        }
        td
        {
            padding-top: .5vw !important;
            padding-left: .5vw !important;
            padding-right: 4vw !important;
        }
    </style>
    <style type="text/css">

    </style>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <!-- <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script> -->
    <!-- <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script> -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
</head>
<body>
    <div id="non-printable">


       <!-- <p>Click the button to print the Order.</p> -->
       <!-- <button class="btn btn-info" >BACK</button> -->
<a href="order_view.php?order_id="></a>
       <button class="btn btn-primary" onclick="window.print();">Print this page</button>
       <!-- <button onclick="window.print();">Print this page</button> -->

   </div>

   <div class="container" id="printable" style="*border: 1px solid black;">

    <div class="row">
        <div style="width: 65%;float: right;padding-top: 5vw;padding-right: 5vw;"><h2 style=";font-weight: bold;">Store Bill</h2></div>
        <div style="width: 35%;float: left;"><img  style="margin-left:4vw;" src="../images/logo.jpg" width="150px"></div>
    </div>
    <div class="row">
        <div style="width: 50%;float: left;">
            <table style="margin-left: 4vw;" border="1"><tr><td>NAME</td><td style="width: 25vw;"><?php echo $item_name;?></td></tr><tr><td>ID NO</td><td > 354210</td></tr></table>
        </div>
        <div style="width: 50%;float: right;">
            <table border="1"><tr><td>ORDER NO</td><td style="width: 25vw;">6547891</td></tr><tr><td>ORDER DATE</td><td colspan="2"> 20/10/2019</td></tr></table>
        </div>
    </div>

    <div class="row">
        <div style="margin-top: 1vw;">
            <h4 style="margin-left: 4vw;"><b>PRODUCT DETAILS</b></h4>
            <table border="1" style="margin-left: 4vw;">
                <tr><td style="width: 10vw;">ART NO</td><td style="width: 45vw;"></td><td style="width: 15vw;"> DELIVERY DATE</td></tr>
                <tr><td>ITEM </td><td></td><td rowspan="4" style="text-align: center;margin-bottom: 2vw;"><h2>20/10/2019</h2> </td></tr>
                <tr><td>DESCRIPTION </td><td></td></tr>
                <tr><td>FABRIC </td><td></td></tr>
            </table>
        </div> 

    </div>



    <div style="margin-top: 1vw;" class="row">
        <div>
            <h4 style="margin-left: 4vw;"><b>ADD ON</b></h4>
            <table border="1" style="margin-left: 4vw;">
                <tr><td style="width: 10vw;">1</td><td style="width: 45vw;"></td></tr>
                <tr><td style="width: 10vw;">2</td><td style="width: 45vw;"></td></tr>
                <tr><td style="width: 10vw;">3</td><td style="width: 45vw;"></td></tr>
                <tr><td style="width: 10vw;">4</td><td style="width: 45vw;"></td></tr>
            </table>
        </div> 

    </div>

    <div style="margin-top: 1vw;" class="row">
        <div>
            <h4 style="margin-left: 4vw;"><b>SIZE</b></h4>
            <table border="1" style="margin-left: 4vw;">
                <tr><td>XXS</td><td>XS</td><td>S</td><td>M</td><td>L</td><td>XL</td><td>XXL</td><td>XXXL</td><td>TOTAL</td></tr>
                <tr><td>1</td><td>2</td><td>3</td><td>4</td><td>5</td><td>6</td><td>7</td><td>8</td><td>120</td></tr></table>


            </div> 

        </div>
        <div style="margin-top: 1vw;" class="row">
            <div>
                <h4 style="margin-left: 4vw;"><b>PHOTOS</b></h4>
                <table border="1"  style="margin-left: 4vw;">
                    <tr><td>ITEM PHOTO</td>
                       <td>
                        <table style="border: none;"><tr><td>Logo/Matter1 </td></tr><tr><td>Location</td></tr><tr><td>Pdf File No</td></tr></table>
                    </td>
                    <td>
                        <table style="border: none;"><tr><td>Logo/Matter1 </td></tr><tr><td>Location</td></tr><tr><td>Pdf File No</td></tr></table>
                    </td>
                </tr>
                <tr style="height: 13vw;"><td>ITEM</td><td>FOR ADDON</td><td>FOR ADDON</td></tr>
                <tr><td>        
                    <table style="border: none;"><tr><td>Logo/Matter1 </td></tr><tr><td>Location</td></tr><tr><td>Pdf File No</td></tr></table>
                </td>
                <td>                <table style="border: none;"><tr><td>Logo/Matter1 </td></tr><tr><td>Location</td></tr><tr><td>Pdf File No</td></tr></table>
            </td>
            <td>                <table style="border: none;"><tr><td>Logo/Matter1 </td></tr><tr><td>Location</td></tr><tr><td>Pdf File No</td></tr></table>
        </td>
    </tr>
    <tr style="height: 13vw;"><td></td><td>FOR ADDON</td><td>FOR ADDON</td></tr>

</table>


</div> 

</div>


<div style="margin-top: 2vw;" class="row">
    <div>
      <table border="1" style="margin-left: 4vw;">
        <tr><td>ART NO</td><td>PARTICULARS</td><td>QTY</td><td>PRICE</td><td>AMOUNT</td><td>ADVANCE</td><td>BALANCE</td></tr>
        <tr><td>A</td><td>B</td><td>C</td><td>D</td><td>E</td><td>F</td><td>G</td></tr>
    </table>
    <h4 style="margin-top: 1vw;margin-left: 4vw;">ADVANCE PAID DATE :</h4>
</div> 

</div>
</div>


<script>
    function print_new() {
      window.print();
  }
</script>

</body>



