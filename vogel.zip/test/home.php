<!DOCTYPE html>
<html>
<head>

	<title>
	home
	</title>
</head>
<body>
<div id="test">
	<img src="images/logo1.jpg"> 
	aaaaaaaa
<!-- aaaaaaaaaaaaaaaaa -->
<!-- <img src="images/logo1.jpg"  "> -->
</div>
</body>
</html>