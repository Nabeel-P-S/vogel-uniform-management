<!DOCTYPE html>
<html>
<head>
	<title>d</title>
</head>
<body>

  <select id="create_type" name="usertype" style="border-radius: 1vw;" onchange="my_function('1',this.value);">
    <option value="0">Select  Type</option>
    <option value="1">ARTICLE/ITEM</option>
    <option value="2">CUSTOMER/SHOP</option>
     
    <option value="6">ORDER</option>
    <option value="3">VENDOR/FACTORY</option>
    <option value="4">ITEM CATEGORY</option>
    <option value="5">ADD ON</option>
  </select>

</body>
</html>