-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 18, 2019 at 07:05 AM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `vogel`
--

-- --------------------------------------------------------

--
-- Table structure for table `addons`
--

CREATE TABLE `addons` (
  `addon_id` int(11) NOT NULL,
  `addon` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addons`
--

INSERT INTO `addons` (`addon_id`, `addon`) VALUES
(1, 'Chest Logo'),
(2, 'Front Print'),
(3, 'print 3 mm front');

-- --------------------------------------------------------

--
-- Table structure for table `addon_price`
--

CREATE TABLE `addon_price` (
  `addon_price_id` int(11) NOT NULL,
  `addon_id` int(11) NOT NULL,
  `quantity_id` int(11) NOT NULL,
  `addon_price` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addon_price`
--

INSERT INTO `addon_price` (`addon_price_id`, `addon_id`, `quantity_id`, `addon_price`) VALUES
(1, 1, 1, '10'),
(2, 1, 2, '8'),
(3, 1, 3, '5'),
(4, 2, 1, '6'),
(5, 2, 2, '4'),
(6, 2, 3, '3'),
(7, 3, 1, '10'),
(8, 3, 2, '8'),
(9, 3, 3, '5');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `customer_id` int(11) NOT NULL,
  `shop_name` varchar(250) NOT NULL,
  `customer_name` varchar(250) NOT NULL,
  `customer_address` varchar(250) NOT NULL,
  `customer_place` varchar(250) NOT NULL,
  `customer_pincode` varchar(250) NOT NULL,
  `customer_district` varchar(250) NOT NULL,
  `customer_state` varchar(250) NOT NULL,
  `customer_country` varchar(250) NOT NULL,
  `customer_email` varchar(200) NOT NULL,
  `customer_mobile1` varchar(200) NOT NULL,
  `customer_mobile2` varchar(200) NOT NULL,
  `customer_adhar` varchar(250) NOT NULL,
  `customer_license` varchar(250) NOT NULL,
  `customer_status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customer_id`, `shop_name`, `customer_name`, `customer_address`, `customer_place`, `customer_pincode`, `customer_district`, `customer_state`, `customer_country`, `customer_email`, `customer_mobile1`, `customer_mobile2`, `customer_adhar`, `customer_license`, `customer_status`) VALUES
(1, 'Fa Fa Fashion ', 'Surendran  K T', 'opposite Kunnamkulam bus stand', 'Kunnamkulam', '680501', 'Thrissur', 'Kerala', '', 'jhjgqeueg@gmail.com', '9865141237', '3652147896', '354476302365', '6545495998', 1);

-- --------------------------------------------------------

--
-- Table structure for table `factory_addon_price`
--

CREATE TABLE `factory_addon_price` (
  `factory_addon_cost_id` int(11) NOT NULL,
  `addon_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `quantity_id` int(11) NOT NULL,
  `factory_addon_cost` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factory_addon_price`
--

INSERT INTO `factory_addon_price` (`factory_addon_cost_id`, `addon_id`, `vendor_id`, `quantity_id`, `factory_addon_cost`) VALUES
(1, 1, 2, 1, '5'),
(2, 1, 2, 2, '5'),
(3, 1, 2, 3, '5'),
(4, 2, 2, 1, '3'),
(5, 2, 2, 2, '3'),
(6, 2, 2, 3, '3'),
(7, 1, 2, 1, ''),
(8, 1, 2, 2, ''),
(9, 1, 2, 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `factory_cost`
--

CREATE TABLE `factory_cost` (
  `factory_item_cost_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `vendor_id` int(11) NOT NULL,
  `quantity_id` int(11) NOT NULL,
  `factory_item_cost` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `factory_cost`
--

INSERT INTO `factory_cost` (`factory_item_cost_id`, `item_id`, `vendor_id`, `quantity_id`, `factory_item_cost`) VALUES
(1, 1, 1, 1, '10'),
(2, 1, 1, 2, '8'),
(3, 1, 1, 3, '5'),
(4, 1, 2, 1, '12'),
(5, 1, 2, 2, '8'),
(6, 1, 2, 3, '6'),
(7, 1, 2, 1, ''),
(8, 1, 2, 2, ''),
(9, 1, 2, 3, '');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `item_id` int(11) NOT NULL,
  `item_no` int(11) NOT NULL,
  `item_name` varchar(250) NOT NULL,
  `item_category_id` int(11) NOT NULL,
  `item_image` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`item_id`, `item_no`, `item_name`, `item_category_id`, `item_image`) VALUES
(1, 1, 'mund', 3, ''),
(2, 2, 'mund22', 3, 'download_2019-09-16 11-16-08.jpg'),
(3, 3, 'T-Shirt', 4, 'INSTA POST 3_2019-09-16 01-32-18.jpg'),
(4, 4, 'test', 3, 'download_2019-09-16 01-37-10.jpg'),
(5, 5, 'sample', 3, 'INSTA POST 3_2019-09-16 01-46-35.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `item_categories`
--

CREATE TABLE `item_categories` (
  `category_id` int(11) NOT NULL,
  `category` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_categories`
--

INSERT INTO `item_categories` (`category_id`, `category`) VALUES
(1, 'School Uniform'),
(2, 'Office Uniform'),
(3, 'Casual Dress'),
(4, 'Restarunt Uniform'),
(5, 'Perunnal dress'),
(6, 'Festival dress');

-- --------------------------------------------------------

--
-- Table structure for table `item_cost`
--

CREATE TABLE `item_cost` (
  `item_cost_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity_id` int(11) NOT NULL,
  `item_cost` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `item_cost`
--

INSERT INTO `item_cost` (`item_cost_id`, `item_id`, `quantity_id`, `item_cost`) VALUES
(1, 1, 1, '15'),
(2, 1, 2, '12'),
(3, 1, 3, '10'),
(4, 2, 1, '55'),
(5, 2, 2, '28'),
(6, 2, 3, '10'),
(7, 3, 1, '35'),
(8, 3, 2, '20'),
(9, 3, 3, '10'),
(10, 4, 1, '3'),
(11, 4, 2, '3'),
(12, 4, 3, '3'),
(13, 5, 1, '6'),
(14, 5, 2, '5'),
(15, 5, 3, '3');

-- --------------------------------------------------------

--
-- Table structure for table `item_quantity`
--

CREATE TABLE `item_quantity` (
  `quantity_id` int(11) NOT NULL,
  `quantity_details` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `old_orders`
--

CREATE TABLE `old_orders` (
  `id` int(11) NOT NULL,
  `order_no` int(11) NOT NULL,
  `order_date` date NOT NULL,
  `order_category_id` int(11) NOT NULL,
  `order_unit_id` int(11) NOT NULL,
  `order_quantity` varchar(250) NOT NULL,
  `order_customer_id` int(11) NOT NULL,
  `odrer_confirm_date` datetime NOT NULL,
  `order_send_date` date NOT NULL,
  `order_set_date` datetime NOT NULL,
  `order_recieve_date` datetime NOT NULL,
  `order_dispatch_date` date NOT NULL,
  `amount` varchar(250) NOT NULL,
  `charge1` varchar(200) NOT NULL,
  `charge2` varchar(200) NOT NULL,
  `charge3` varchar(250) NOT NULL,
  `charge4` varchar(250) NOT NULL,
  `charge5` varchar(250) NOT NULL,
  `discount` varchar(250) NOT NULL,
  `total` varchar(250) NOT NULL,
  `advance` varchar(250) NOT NULL,
  `balance` varchar(250) NOT NULL,
  `advance_status` int(11) NOT NULL,
  `production_status` int(11) NOT NULL,
  `fabric_status` int(11) NOT NULL,
  `stitch_status` int(11) NOT NULL,
  `pack_status` int(11) NOT NULL,
  `resend_status` int(11) NOT NULL,
  `dispatch_status` int(11) NOT NULL DEFAULT '0',
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `payment_status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` datetime NOT NULL,
  `delivery_date` date NOT NULL,
  `customer_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `order_quantity` varchar(250) NOT NULL,
  `factory_id` int(11) NOT NULL,
  `order_cost` varchar(250) NOT NULL,
  `order_factory_cost` varchar(250) NOT NULL,
  `advance_status` int(11) NOT NULL DEFAULT '0',
  `production_status` int(11) NOT NULL DEFAULT '0',
  `fabric_status` int(11) NOT NULL DEFAULT '0',
  `stitch_status` int(11) NOT NULL DEFAULT '0',
  `pack_status` int(11) NOT NULL DEFAULT '0',
  `store_status` int(11) NOT NULL DEFAULT '0',
  `dispatch_status` int(11) NOT NULL DEFAULT '0',
  `delivery_status` int(11) NOT NULL DEFAULT '0',
  `payment_status` int(11) NOT NULL DEFAULT '0',
  `status` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_date`, `delivery_date`, `customer_id`, `item_id`, `order_quantity`, `factory_id`, `order_cost`, `order_factory_cost`, `advance_status`, `production_status`, `fabric_status`, `stitch_status`, `pack_status`, `store_status`, `dispatch_status`, `delivery_status`, `payment_status`, `status`) VALUES
(1, '2019-09-14 11:07:19', '2019-09-11', 1, 1, '40', 1, '400', '200', 1, 1, 1, 1, 1, 0, 0, 1, 0, 'Packed'),
(2, '2019-09-15 11:27:18', '0000-00-00', 0, 0, '', 0, '', '', 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
(3, '2019-09-16 01:33:34', '2019-09-19', 1, 3, '34', 2, '340', '0', 0, 1, 1, 0, 0, 0, 0, 0, 0, 'Store Reached'),
(4, '2019-09-16 01:47:13', '2019-09-12', 1, 5, '28', 2, '84', '0', 1, 1, 1, 1, 1, 1, 0, 0, 0, 'Packed');

-- --------------------------------------------------------

--
-- Table structure for table `order_addons`
--

CREATE TABLE `order_addons` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `addon_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_addons`
--

INSERT INTO `order_addons` (`id`, `order_id`, `addon_id`) VALUES
(1, 1, 1),
(2, 3, 2),
(3, 3, 3),
(4, 4, 2);

-- --------------------------------------------------------

--
-- Table structure for table `order_quantity`
--

CREATE TABLE `order_quantity` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `size_id` int(11) NOT NULL,
  `order_quantity` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_quantity`
--

INSERT INTO `order_quantity` (`id`, `order_id`, `size_id`, `order_quantity`) VALUES
(1, 1, 1, '5'),
(2, 1, 2, '5'),
(3, 1, 3, '5'),
(4, 1, 4, '5'),
(5, 1, 5, '5'),
(6, 1, 6, '5'),
(7, 1, 7, '5'),
(8, 1, 8, '5'),
(9, 3, 1, '5'),
(10, 3, 2, '3'),
(11, 3, 3, '9'),
(12, 3, 4, '5'),
(13, 3, 5, '2'),
(14, 3, 6, '1'),
(15, 3, 7, '3'),
(16, 3, 8, '6'),
(17, 4, 1, '6'),
(18, 4, 2, '6'),
(19, 4, 3, '3'),
(20, 4, 4, '2'),
(21, 4, 5, '6'),
(22, 4, 7, '2'),
(23, 4, 8, '3');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `size_id` int(11) NOT NULL,
  `size` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`size_id`, `size`) VALUES
(1, 'XXS'),
(2, 'XS'),
(3, 'S'),
(4, 'M'),
(5, 'L'),
(6, 'XL'),
(7, 'XXL'),
(8, 'XXXL');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `created_at`, `status`) VALUES
(1, 'nabeel', '$2y$10$551WmOf/JskxE7jkeEGTbOC/3bUdikrV0Cn10jsbI990vxMfd5jQ2', '2019-09-12 09:45:31', 0),
(2, 'vogel', '$2y$10$Ttcfkmo1kWGymCLN6KfMuOJoPwFokknGWoZvpVqqUbwwSEUN0lAIK', '2019-09-16 18:01:56', 0),
(3, 'admin', '$2y$10$GCj77JGGYiDFf2XxuG0TEe3etzX79HW4W766JmqrNMEw0cVGMgaKS', '2019-09-16 20:13:28', 0);

-- --------------------------------------------------------

--
-- Table structure for table `vendors`
--

CREATE TABLE `vendors` (
  `vendor_id` int(11) NOT NULL,
  `factory_name` varchar(250) NOT NULL,
  `vendor_name` varchar(250) NOT NULL,
  `vendor_address` varchar(250) NOT NULL,
  `vendor_place` varchar(250) NOT NULL,
  `vendor_district` varchar(250) NOT NULL,
  `vendor_state` varchar(250) NOT NULL DEFAULT 'Kerala',
  `vendor_pincode` varchar(250) NOT NULL,
  `vendor_email` varchar(250) NOT NULL,
  `vendor_mobile1` varchar(200) NOT NULL,
  `vendor_mobile2` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `vendors`
--

INSERT INTO `vendors` (`vendor_id`, `factory_name`, `vendor_name`, `vendor_address`, `vendor_place`, `vendor_district`, `vendor_state`, `vendor_pincode`, `vendor_email`, `vendor_mobile1`, `vendor_mobile2`) VALUES
(1, 'badusha factory', 'badusha', 'thiruppor bus stand', 'chennai', 'Thiruvananthapuram', 'Kerala', '996666', 'gsy', '995+99+89', '598989'),
(2, 'yahyas exports', 'Jamshi', 'Jamshi P B', 'Choondal', 'Thrissur', 'Kerala', '680502', 'gvgxgf@gmail.com', '9856321457', '6684512365');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addons`
--
ALTER TABLE `addons`
  ADD PRIMARY KEY (`addon_id`);

--
-- Indexes for table `addon_price`
--
ALTER TABLE `addon_price`
  ADD PRIMARY KEY (`addon_price_id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`customer_id`);

--
-- Indexes for table `factory_addon_price`
--
ALTER TABLE `factory_addon_price`
  ADD PRIMARY KEY (`factory_addon_cost_id`);

--
-- Indexes for table `factory_cost`
--
ALTER TABLE `factory_cost`
  ADD PRIMARY KEY (`factory_item_cost_id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`item_id`);

--
-- Indexes for table `item_categories`
--
ALTER TABLE `item_categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `item_cost`
--
ALTER TABLE `item_cost`
  ADD PRIMARY KEY (`item_cost_id`);

--
-- Indexes for table `item_quantity`
--
ALTER TABLE `item_quantity`
  ADD PRIMARY KEY (`quantity_id`);

--
-- Indexes for table `old_orders`
--
ALTER TABLE `old_orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_addons`
--
ALTER TABLE `order_addons`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_quantity`
--
ALTER TABLE `order_quantity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`size_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `vendors`
--
ALTER TABLE `vendors`
  ADD PRIMARY KEY (`vendor_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addons`
--
ALTER TABLE `addons`
  MODIFY `addon_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `addon_price`
--
ALTER TABLE `addon_price`
  MODIFY `addon_price_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `customer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `factory_addon_price`
--
ALTER TABLE `factory_addon_price`
  MODIFY `factory_addon_cost_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `factory_cost`
--
ALTER TABLE `factory_cost`
  MODIFY `factory_item_cost_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `item_categories`
--
ALTER TABLE `item_categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `item_cost`
--
ALTER TABLE `item_cost`
  MODIFY `item_cost_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `item_quantity`
--
ALTER TABLE `item_quantity`
  MODIFY `quantity_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `old_orders`
--
ALTER TABLE `old_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_addons`
--
ALTER TABLE `order_addons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `order_quantity`
--
ALTER TABLE `order_quantity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `size_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `vendors`
--
ALTER TABLE `vendors`
  MODIFY `vendor_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
