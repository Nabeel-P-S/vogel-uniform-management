
<?php include "../connect.php";
date_default_timezone_set('Asia/Kolkata');
$date = date("Y-m-d H:i:s");
// echo $date;
$store_date = date('Y-m-d',(strtotime ( '7 day' , strtotime ( $date) ) ));
$store_delivery_date = date('Y-m-d',(strtotime ( '15 day' , strtotime ( $date) ) ));

?>
<!DOCTYPE html>
<html>
<head>
  <title></title>
</head>
<style type="text/css">
  .button4
  {
   width:250px;
  height:40px;
  left:750px;
  top:625px;
  background:#2196f3;
  font-family:verdana;
  font-size:18px;
  color:white;
  border-radius:5px 5px 5px 5px;
  border-width: 1px;
  border-style:solid;
  border-color: gray;
  cursor:pointer;
  outline:none;
  margin-top: 1vw;
  }
</style>
<body>
   <h1><b style="font-size:25px;color:#2196f3">Create Order</b></h1>
  <form id="order_form" enctype="multipart/form-data">
    <?php 
    $query=mysqli_query($conn,"select order_id from orders order by order_id desc LIMIT 1
     ");
    $fetch=mysqli_fetch_array($query);
    $order_id=$fetch['order_id'];
    $order_id=$order_id+'1';
    ?>


    <table  border="1" class="table table-striped">
      <tbody>
       <tr>
        <td style="width: 20vw;" >


         <!-- ==================================ITEM BOX =============================================                  -->

         <div class="well form-horizontal">
          <fieldset>


      <label  class="col-md-12" for="factory_number">Select Agent</label>  
      <div class="form-group">


        <div class="col-md-10 inputGroupContainer">

          
         <div class="input-group">

          <select class="selectpicker form-control" id="customer_id" onchange="*display_customer(this.value)" name="customer_id">
            <option style="color: grey" value="" >select Agent</option>
           <?php  
           $query=mysqli_query($conn,"SELECT customer_id,customer_name from customers");
           while($fetch=mysqli_fetch_array($query))
           {
            ?>
            <option value="<?php echo $fetch ['customer_id']; ?>"><?php echo $fetch ['customer_name']." ".$fetch ['customer_id'];?> </option>
            <?php
          }
          ?> 


        </select>
      </div>
    </div>

  </div>


  <div class="form-group">


    <div class="col-md-12" id="customer_div">                     
   <!--  <textarea class="form-control" style="height: 10vw;" id="customer_details" name="customer_details">
     
   </textarea> -->
 </div>
</div>




</fieldset>
          <fieldset>


            <label class="col-md-12 " for="factory_number">Select Item</label>  
            <div class="form-group">
              <div class="col-md-12">
                <select id="item_id"  name="item_id" onchange="*display_item(this.value)" class="form-control">
                  <option style="color: grey" value="" >select Item</option>
                  <?php  
                  $query=mysqli_query($conn,"SELECT * from items");
                  while($fetch=mysqli_fetch_array($query))
                  {
                    ?>
                    <option value="<?php echo $fetch ['item_id']; ?>"><?php echo $fetch ['item_name']." ".$fetch ['item_id'];?> </option>
                    <?php
                  }
                  ?> 
                </select>      
              </div>
            </div>

            <div class="form-group">

              <div class="col-md-12" id="item_div">                     
   <!--  <textarea class="form-control" style="height: 10vw;" id="customer_details" name="customer_details">
     
   </textarea> -->
 </div>
</div>  
<!-- onchange="display_addon(this.value);" -->
</fieldset>

 <fieldset>


            <label class="col-md-12 " for="factory_number">Select Fabric</label>  
            <div class="form-group">
              <div class="col-md-12">
                <select id="fabric_id"  name="fabric_id" onchange="*display_item(this.value)" class="form-control">
                  <option style="color: grey" value="" >select Fabric</option>
                  <?php  
                  $query=mysqli_query($conn,"SELECT * from fabric");
                  while($fetch=mysqli_fetch_array($query))
                  {
                    ?>
                    <option value="<?php echo $fetch ['fabric_id']; ?>"><?php echo $fetch ['fabric']." ".$fetch ['fabric_id'];?> </option>
                    <?php
                  }
                  ?> 
                </select>      
              </div>
            </div>

            <div class="form-group">

              <div class="col-md-12" id="item_div">                     
   <!--  <textarea class="form-control" style="height: 10vw;" id="customer_details" name="customer_details">
     
   </textarea> -->
 </div>
</div>  
<!-- onchange="display_addon(this.value);" -->
</fieldset>
<!-- --------------------------------------------addon div---below-------------------------------------------------------------------------- -->
<label class="col-md-12 " for="factory_number">Select Addons</label>  
<table id="addon_table1">
  <tr>
    <td>
        <select id="addon_id" class="form-control input-md" name="addon_id" >
          <option style="color: grey" value="" >select addon
          </option>
          <?php  
            $query=mysqli_query($conn,"SELECT * from addons");
            while($fetch=mysqli_fetch_array($query))
            {
              ?>
              <option value="<?php echo $fetch ['addon_id']; ?>"><?php echo  $fetch ['addon_id'].".".$fetch ['addon']."-".$fetch ['addon_price1'].",".$fetch ['addon_price2'].",".$fetch ['addon_price3'];?> </option><?php
            }
            ?>    </select>          


      </td>
      <td></td>
  </tr>
    
</table>
    <button type="button"  id="add" name="add" class="btn btn-success" onclick="add_addon(this,'addon_table1')">+ ADD</button>
    <input type="hidden" id="addon_row_count" value="1">
    <input  type="hidden" id="addon_cost_sum" value="0">
    <input  type="hidden"  id="factory_addon_cost_sum" value="0">
    <!-- --------------------------------------------addon div---above-------------------------------------------------------------------------- -->


   <!-- /////////////////////////    IMAGES TABLE     ///////////////////////////////////////////////////////////////////////////// -->

   <form id="image_table"  method="post" enctype="multipart">
    <table><tr ><td >
       <input type="text" name="order_id" id="order_id" value="" style="display:none;">
      <img src="images/profile.png" id="order_image" alt="" width="100px" > 
      <input type="file" id="image_id" name="image_id" style="width: 7vw;font-size:1vw;"   onchange="view_image();">

    </td></tr>

  </table>
</form>
<br>
 <button type="button"  onclick="order_image_insert()" class="btn btn-primary ">Save Image</button>

  <script type="text/javascript">
          function view_image()
          {
                document.getElementById("order_image").src= URL.createObjectURL(event.target.files[0]);
          }
        </script>
        <script type="text/javascript">

         function order_image_insert()
         {
                var form = new FormData(document.getElementById('image_table'));

               alert("inserting1");
                 var file = document.getElementById('image_id').files[0];
                      if (file)
                      {   
                         form.append('image_id', file);
                      }
                      alert(image_id);
              
                          $.ajax({
                            type: "POST",
                            url: "insert/order_image_upload.php",
                              // dataType:"json",
                            data: form, 
                            cache: false,
                            contentType: false, //must, tell jQuery not to process the data
                            processData: false,
                         //data: $("#upload_img").serialize(),
                       success: function(data)
                      {
                        // alert(data);
                         swal("success","Order inserted","success");
                                    my_function('1','6');
                      }
                    });
                       }

                  </script>

    <!-- /////////////////////////    IMAGES TABLE     ///////////////////////////////////////////////////////////////////////////// -->





    <!-- <input type="text" name="item_id" id="item_id" value="" style="display:none;"> -->





  


</div>
<!-- ==================================ITEM BOX ABOVE=============================================                  -->



</td>
<td colspan="3">


 <!-- ==================================ORDER BOX =============================================                  -->


 <div class="well form-horizontal">

  <!-- ===== -->
<div class="form-group field-wrapper ">
  <div class="col-md-6"> 
    <label class="col-md-12" >Order No</label>  
            <div class="form-group">
              <div class="col-md-12">
 <input id="order_no" readonly="1" value="<?php echo $order_id;?>" name="order_no" type="text"  class="form-control input-md">              </div>
            </div></div>

            <div class="col-md-6">   <label class="col-md-12 " for="factory_number">Ref.No</label>  
            <div class="form-group">
              <div class="col-md-12">
 <input id="reference_no"   name="reference_no" type="text" placeholder="Reference No" class="form-control input-md">              </div>
            </div></div>

          </div>
          <div class="form-group field-wrapper ">
 <div class="col-md-4"> 
 <label class="col-md-12 ">Order Date</label>
                        <div class="col-md-12">
     <input type="datetime" id="order_date" name="order_date" placeholder="Dob" class="form-control" required="true" value="<?php echo $date;?>" >
              </div>
           </div>
  
  <div class="col-md-4"> 
 <label class="col-md-12" >Store Delivery</label>
                        <div class="col-md-12">
    <input type="date" id="store_delivery_date" name="store_delivery_date" placeholder="Dob" class="form-control" required="true" value="<?php echo $store_date;?>" >
              </div>
           </div>

          <div class="col-md-4"> 
 <label class="col-md-12">Main Delivery</label>
                        <div class="col-md-12">
    <input type="date" id="main_delivery_date" name="main_delivery_date" placeholder="Dob" class="form-control" required="true" value="<?php echo $store_delivery_date;?>" >
              </div>
           </div>
 
</div>


                    
<div class="form-group field-wrapper ">
  <div class="col-md-10"> <div class="form-group">
    <label class="col-md-12 ">Quantity</label>
    <div class="col-md-12 inputGroupContainer">
     <div class="input-group">
      <input id="quantity1" style="width: 5vw;" name="quantity1" type="text" placeholder="xxs" onkeyup="display_total();" class="form-control input-md">
      <input id="quantity2" style="width: 5vw;" name="quantity2" type="text" placeholder="xs" onchange="display_total();" class="form-control input-md">
      <input id="quantity3" style="width: 5vw;" name="quantity3" type="text" placeholder="s" onchange="display_total();" class="form-control input-md">
      <input id="quantity4" style="width: 5vw;" name="quantity4" type="text" placeholder="m" onchange="display_total();" class="form-control input-md">
     <input id="quantity5" style="width: 5vw;" name="quantity5" type="text" placeholder="l" onchange="display_total();" class="form-control input-md">
      <input id="quantity6" style="width: 5vw;" name="quantity6" type="text" placeholder="xl" onchange="display_total();" class="form-control input-md">
      <input id="quantity7" style="width: 5vw;" name="quantity7" type="text" placeholder="xxl" onchange="display_total();" class="form-control input-md">
      <input id="quantity8" style="width: 5vw;" name="quantity8" type="text" placeholder="xxxl" onchange="display_total();"  class="form-control input-md">
    </div>
  </div>
</div></div>
  <div class="col-md-2"><div class="form-group field-wrapper">
  <label class="col-md-12">Total </label>
  <div class="col-md-12 ">
   <input type="text" id="total_qty" name="total"  class="form-control"  type="txt"></div>
   <input type="hidden" id="quantity_id" ></div>


</div></div>


 




<div class="form-group field-wrapper ">
  <div class="col-md-3">   <label class="col-md-12 " >Item Cost</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="item_cost" name="item_cost"  class="form-control"  type="txt">
              </div>
            </div></div>
  <div class="col-md-3"> 
    <label class="col-md-12 " >Addon Cost</label>  

                        <div class="col-md-12">
               <input type="text" id="addon_cost" name="addon_cost"  class="form-control"  type="txt">
              </div>
           </div>

  <div class="col-md-3"> 
    <label class="col-md-12 " >fabric Cost</label>  

                        <div class="col-md-12">
               <input type="text" id="fabric_price" name="fabric_price"  class="form-control"  type="txt">
              </div>
           </div>
  <div class="col-md-3">   <label class="col-md-12 " for="factory_number">Total Cost</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="total_cost" name="total_cost"  class="form-control"  type="txt">
              </div>
            </div></div>
</div>








        
<div class="form-group field-wrapper ">
  <div class="col-md-6">

    <label class="col-md-12 control-label" for="factory_number">Select Factory</label>  
    <div class="form-group">
     <div class="col-md-12 inputGroupContainer">
       <div class="input-group"><span class="input-group-addon" ></span>
<!-- onchange="display_vendor(this.value);display_factory_addon_cost(this.value);display_factory_item_cost(this.value);" -->
        <!-- <select class="selectpicker form-control" id="vendor_id" onchange="display_factory_item_cost(this.value);display_vendor(this.value);"  name="vendor_id"> -->
        <select class="selectpicker form-control" id="vendor_id" onchange="display_factory_item_cost(this.value);"  name="vendor_id">
<option style="color: grey" value="" >select Factory</option>
         <?php  
         $query=mysqli_query($conn,"SELECT vendor_id,factory_name from vendors");
         while($fetch=mysqli_fetch_array($query))
         {
          ?>
          <option value="<?php echo $fetch ['vendor_id']; ?>"><?php echo $fetch ['factory_name']." ".$fetch ['vendor_id'];?> </option>
          <?php
        }
        ?> 

      </select>
    </div>
  </div>
 

</div>
  </div>

  <div class="col-md-6">
   
  <div class="form-group">

  <div class="col-md-6" id="item_div1">                     
  
 </div>

  <div class="col-md-6" id="addon_div">                     
  
 </div>
</div>  
  </div>
</div>




<div class="form-group field-wrapper ">
  <div class="col-md-3">   <label class="col-md-12">Factory Item Cost</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="factory_item_cost" name="factory_item_cost"  class="form-control"  type="txt">
              </div>
            </div></div>
  <div class="col-md-3"> 
    <label class="col-md-12 " >Factory Addon Cost</label>  
                        <div class="col-md-12">
               <input type="text" id="factory_addon_cost" name="factory_addon_cost"  class="form-control"  type="txt">
              </div>
           </div>
  <div class="col-md-3"> 
    <label class="col-md-12 " >Factory Fabric Cost</label>  
                        <div class="col-md-12">
               <input type="text" id="factory_fabric_cost" name="factory_fabric_cost"  class="form-control"  type="txt">
              </div>
           </div>

  <div class="col-md-3">   <label class="col-md-12 " for="factory_number">Factory Total Cost</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="factory_total_cost" name="factory_total_cost"  class="form-control"  type="txt">
              </div>
            </div></div>
</div>

<!-- ---------------------------------------PAYMENT PAYMENT------------ BELOW--------------------------------------- -->
<div class="form-group field-wrapper ">
    <div class="col-md-4">   <label class="col-md-12 " >Agent Order Cost</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="order_total_cost" name="order_total_cost"  class="form-control"  type="txt">
              </div>
            </div></div>
    <div class="col-md-4">   <label class="col-md-12 " >Agent Advance</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="advance_amount" name="advance_amount" onkeyup="display_balance();"  class="form-control"  type="txt">
              </div>
            </div></div>
               <div class="col-md-4">   <label class="col-md-12 " >Agent Balance</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="balance_amount" name="balance_amount"  class="form-control"  type="txt">
              </div>
            </div></div>
       
</div>

<div class="form-group field-wrapper ">
    <div class="col-md-4">   <label class="col-md-12 " >Factory Order Cost</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="factory_order_total_cost" name="factory_order_total_cost"  class="form-control"  type="txt">
              </div>
            </div></div>
    <div class="col-md-4">   <label class="col-md-12 " >Factory Advance</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="factory_advance_amount" name="factory_advance_amount" onkeyup="display_factory_balance();"  class="form-control"  type="txt">
              </div>
            </div></div>
               <div class="col-md-4">   <label class="col-md-12 " >Factory Balance</label>  
            <div class="form-group">
              <div class="col-md-12">
               <input type="text" id="factory_balance_amount" name="factory_balance_amount"  class="form-control"  type="txt">
              </div>
            </div></div>
       
</div>

<!-- ---------------------------------------PAYMENT PAYMENT--ABOVE------------------------------------------------- -->


     <button type="button" style="*margin-left: 13vw;" onclick="save_order()" class="btn btn-primary ">Submit Order</button>
     <!-- <button type="button" class="button4"  onclick="order_image_insert()">Save Images</button> -->


</div>
<!-- ==================================ORDER BOX ABOVE=============================================                  -->



                            <!-- /////////////////////////////  ORDER IMAGES //////////////////////////////////////// -->

<!-- <div id="order_images" style="*display: none;"> <table style="margin-left: 3vw;" border="0" ><tr >
  <td><img src="images/profile.png" id="order_image1" alt=""   width="100"> <input type="file" id="image_id1" name="image_id"  style="width: 7.7vw;" onchange="view_image('order_image1');"></td><td>
<img src="images/profile.png" id="order_image2" alt=""   width="100"> <input type="file" id="image_id2" name="image_id"  style="width: 7.7vw;" onchange="view_image('order_image2');"></td><td>
<img src="images/profile.png" id="order_image3" alt=""   width="100"> <input type="file" id="image_id3" name="image_id"  style="width: 7.7vw;" onchange="view_image('order_image3');"></td><td>
<img src="images/profile.png" id="order_image4" alt=""   width="100"> <input type="file" id="image_id4" name="image_id"  style="width: 7.7vw;" onchange="view_image('order_image4');"></td><td>
<img src="images/profile.png" id="order_image5" alt=""   width="100"> <input type="file" id="image_id5" name="image_id"  style="width: 7.7vw;" onchange="view_image('order_image5');"></td><td>
</tr></table>
</div> -->

                      <!-- /////////////////////////////  ORDER IMAGES //////////////////////////////////////// -->

</td>
</tr>
<!-- <tr > -->
  <!-- <td colspan="2" > -->

   <!-- ==================================== CUSTOMER BOX ============================= -->

   <!-- <div class="well form-horizontal"> -->
    
<!-- </div> -->
<!-- ==================================cCUSTOMER BOX ABOVE=============================================                  -->









<!-- </td> -->
<!-- <td colspan="2"> -->
 <!-- ==================================FACTORY BOX =============================================                  -->

 <!-- <div class="well form-horizontal"> -->

<!-- </div> -->

<!-- ==================================FACTORY BOX ABOVE=============================================                  -->



</td>
</tr>
</tbody>

</table>

</form>
<script type="text/javascript">
 function display_customer(customer_id)
 {
          // alert(customer_id);
          $.ajax(
          {
            type:"POST",
            url:"details/customer_details.php",
                    // dataType:"json",
                    data:{
                      customer_id:customer_id
                    },

                    success: function(data)

                    {
                      // // alert(data);
                    // document.getElementById('customer_details').value=data;
                    $("#customer_div").html(data);

                    //   swal("success","Order inserted","success");
                    //  my_function('1','5');
                  }    
                });
        }
      </script>
      <script type="text/javascript">
       function display_vendor(vendor_id)
       {

          var item_id=document.getElementById('item_id').value;
          var fabric_id=document.getElementById('fabric_id').value;

              // alert(vendor_id+" deef"+item_id);
          $.ajax(
          {
            type:"POST",
            url:"details/vendor_details.php",
                    // dataType:"json",
                    data:{
                      vendor_id:vendor_id,
                  
                      item_id:item_id,
                      fabric_id:fabric_id
                    },

                    success: function(data)

                    {
                      // alert(data);
                    // document.getElementById('customer_details').value=data;
                    $("#item_div1").html(data);
                    check_addon(vendor_id); 

                    //   swal("success","Order inserted","success");
                    //  my_function('1','5');
                  }    
                });
        }
      </script>

<script type="text/javascript">
       function check_addon(vendor_id)
       {
// alert("adoncheck");
    var addon_array=[];

    var m=0;
    var addon_element=document.getElementsByName('addon_id');
    for (var i = 0; i <addon_element.length; i++) 
    {
    var addon_id=addon_element[i].value;
    if (addon_id!="")
    {
    addon_array[m]=addon_id;
    m++;
    }
    }
    var addon_array_json=JSON.stringify(addon_array);
    // alert(addon_array_json);
    // alert(vendor_id);

          $.ajax(
          {
            type:"POST",
            url:"details/check_addon.php",
                    // dataType:"json",
                    data:{

                      vendor_id:vendor_id,
                      addon_array_json:addon_array_json


                    },

                    success: function(data)

                    {
                      // alert(data);
                    // document.getElementById('customer_details').value=data;
                    $("#addon_div").html(data);
                     

                    //   swal("success","Order inserted","success");
                    //  my_function('1','5');
                  }    
                });
        }
      </script>



      <script type="text/javascript">
       function display_item(item_id)
       {
          // alert(item_id);
          $.ajax(
          {
            type:"POST",
            url:"details/item_details.php",
                    // dataType:"json",
                    data:{
                      item_id:item_id
                    },

                    success: function(data)

                    {
                      // alert(data);
                    // document.getElementById('customer_details').value=data;
                    $("#item_div").html(data);

                    //   swal("success","Order inserted","success");
                    //  my_function('1','5');
                  }    
                });
        }
      </script>

      <script type="text/javascript">
        function save_order()
        {


   
          // alert("saving");
          var addon_array=[];
          var m=0;
          var addon_element=document.getElementsByName('addon_id');
          for (var i = 0; i <addon_element.length; i++) 
          {
            var addon_id=addon_element[i].value;
            if (addon_id!="")
            {
              addon_array[m]=addon_id;
              m++;
            }
          }
          var addon_array_json=JSON.stringify(addon_array);



          var item_id=document.getElementById("item_id").value;


          var quantity1=document.getElementById("quantity1").value;
          if (quantity1=="")
            quantity1=0;
          var quantity2=document.getElementById("quantity2").value;
          if (quantity2=="")
            quantity2=0;
          var quantity3=document.getElementById("quantity3").value;
          if (quantity3=="")
            quantity3=0;
          var quantity4=document.getElementById("quantity4").value;
          if (quantity4=="")
            quantity4=0;
          var quantity5=document.getElementById("quantity5").value;
          if (quantity5=="")
            quantity5=0;
          var quantity6=document.getElementById("quantity6").value;
          if (quantity6=="")
            quantity6=0;
          var quantity7=document.getElementById("quantity7").value;
          if (quantity7=="")
            quantity7=0;
          var quantity8=document.getElementById("quantity8").value;
          if (quantity8=="")
            quantity8=0;
            // alert(quantity1+quantity2+quantity3+quantity4+quantity5+quantity6+quantity7+quantity8);

            var total=document.getElementById("total_qty").value;
            var order_date=document.getElementById("order_date").value;
            var store_delivery_date=document.getElementById("store_delivery_date").value;
            var main_delivery_date=document.getElementById("main_delivery_date").value;
            var customer_id=document.getElementById("customer_id").value;
            var vendor_id=document.getElementById("vendor_id").value;
            var fabric_id=document.getElementById("fabric_id").value;
            var order_item_cost=document.getElementById("item_cost").value;
            var order_addon_cost=document.getElementById("addon_cost").value;
            var order_fabric_price=document.getElementById("fabric_price").value;
            var order_total_cost=document.getElementById("total_cost").value;
            var order_factory_item_cost=document.getElementById("factory_item_cost").value;
            var order_factory_addon_cost=document.getElementById("factory_addon_cost").value;
            var order_factory_fabric_cost=document.getElementById("factory_fabric_cost").value;
            var order_factory_total_cost=document.getElementById("factory_total_cost").value;
            var advance_amount=document.getElementById("advance_amount").value;
            var factory_advance_amount=document.getElementById("factory_advance_amount").value;
            var balance_amount=document.getElementById("balance_amount").value;
            var factory_balance_amount=document.getElementById("factory_balance_amount").value;
            var reference_no=document.getElementById("reference_no").value;
            // alert(reference_no+'fa'+main_delivery_date+'aa'+order_fabric_price+'ww'+order_factory_fabric_cost+'gg'+factory_balance_amount)
          // alert(advance_amount+'a'+balance_amount+'q'+factory_advance_amount+'s'+factory_balance_amount);
            // alert(customer_id+"cc"+vendor_id);

            if(item_id=="" ||vendor_id==""||customer_id==""||fabric_id=="" )
            {       
             swal("ERROR","select item, customer, factory,fabric ","error");
            }
            else

                  {
                    $.ajax(
                    {
                      type:"POST",
                      url:"insert/order_insert.php",
                                  dataType:"json",
                                  data:{  

                                    customer_id:customer_id,
                                    item_id:item_id,
                                    fabric_id:fabric_id,
                                    addon_array_json:addon_array_json,

                                    reference_no:reference_no,
                                    order_date:order_date,
                                    store_delivery_date:store_delivery_date,
                                    main_delivery_date:main_delivery_date,

                                    quantity1:quantity1,
                                    quantity2:quantity2,
                                    quantity3:quantity3,
                                    quantity4:quantity4,
                                    quantity5:quantity5,
                                    quantity6:quantity6,
                                    quantity7:quantity7,
                                    quantity8:quantity8,
                                    total:total,

                                    order_item_cost:order_item_cost,
                                    order_addon_cost:order_addon_cost, 
                                    order_fabric_price:order_fabric_price,
                                    order_total_cost:order_total_cost,

                                    vendor_id:vendor_id,

                                    order_factory_item_cost:order_factory_item_cost,
                                    order_factory_addon_cost:order_factory_addon_cost,
                                    order_factory_fabric_cost:order_factory_fabric_cost,
                                    order_factory_total_cost:order_factory_total_cost,

                                    advance_amount:advance_amount, 
                                    balance_amount:balance_amount,
                                    factory_advance_amount:factory_advance_amount,
                                    factory_balance_amount:factory_balance_amount


                                  },

                                  success: function(data)

                                  {
                                    // alert(data);
// alert("succesfully inserted data");
document.getElementById('item_id').value=data.item_id;
                                    order_image_insert();
                                   
                                    
                                  }    
                                });
                  }


 
        }


</script>
 

        <script>
          function display_total()
          {
          // alert("total");

          var quantity1=document.getElementById("quantity1").value;
          if (quantity1=="")
            quantity1=0;
          var quantity2=document.getElementById("quantity2").value;
          if (quantity2=="")
            quantity2=0;
          var quantity3=document.getElementById("quantity3").value;
          if (quantity3=="")
            quantity3=0;
          var quantity4=document.getElementById("quantity4").value;
          if (quantity4=="")
            quantity4=0;
          var quantity5=document.getElementById("quantity5").value;
          if (quantity5=="")
            quantity5=0;
          var quantity6=document.getElementById("quantity6").value;
          if (quantity6=="")
            quantity6=0;
          var quantity7=document.getElementById("quantity7").value;
          if (quantity7=="")
            quantity7=0;
          var quantity8=document.getElementById("quantity8").value;
          if (quantity8=="")
            quantity8=0;
          var total=parseFloat(quantity1)+parseFloat(quantity2)+parseFloat(quantity3)+parseFloat(quantity4)+parseFloat(quantity5)+parseFloat(quantity6)+parseFloat(quantity7)+parseFloat(quantity8);
          // alert(total);
          document.getElementById("total_qty").value=total;

          
          if (total > 0 && total <= 12)
          {
            var quantity_id='1';

            
          }
          if (total > 12 && total <25)
          {
            var quantity_id='2';
            
          }
          if (total >= 25)
          {
            var quantity_id='3';
            
            


          } document.getElementById("quantity_id").value=quantity_id;
          var item_id=document.getElementById("item_id").value;
          var fabric_id=document.getElementById("fabric_id").value;
          // var vendor_id=document.getElementById("vendor_id").value;
          // alert(item_id+vendor_id)

          $.ajax(
          {
            type:"POST",
            url:"details/item_cost.php",
            dataType:"json",
            data:{
              quantity_id:quantity_id,
              
              item_id:item_id,
              fabric_id:fabric_id
            },

            success: function(data)

            {
// alert(data);
var cost=data.item_cost;
var fabric_price=data.fabric_price;
if (cost==null)
  cost=0;
// alert(fabric_price);
cost= parseFloat(total)*parseFloat(cost)   ;
fabric_price= parseFloat(total)*parseFloat(fabric_price)   ;
// alert(fabric_price);
document.getElementById("item_cost").value=cost; 
document.getElementById("fabric_price").value=fabric_price;
cost=cost+fabric_price; 
document.getElementById("total_cost").value=cost; 
document.getElementById("order_total_cost").value=cost; 

display_addon_cost(quantity_id);

    
}    
});

        }
      </script>


       <script type="text/javascript">
  function display_addon_cost(quantity_id)
  {
    var total= document.getElementById("total_qty").value
    // alert("display_addon_cost");
    var addon_array=[];

    var m=0;

    var addon_element=document.getElementsByName('addon_id');
  
//     if (addon_element.length==0){
//       var item_cost=document.getElementById("item_cost").value;
// document.getElementById("total_cost").value=item_cost; 


//     }
    for (var i = 0; i <addon_element.length; i++) 
      {
        var addon_id=addon_element[i].value;
        if (addon_id!="")
        {
        addon_array[m]=addon_id;
        m++;
        }
      }
    var addon_array_json=JSON.stringify(addon_array);
    // alert(addon_array_json);
        $.ajax({
          type:"POST",
          url:"details/display_addon_cost.php",
          dataType:"json",
          data:{
            addon_array_json:addon_array_json,
            quantity_id:quantity_id

                },
          success:function(data)
          {
              // alert(data);
              var sum4=data.sum4;
              // alert("sum");
              // alert(sum);
              var addon_cost=total*sum4
              document.getElementById("addon_cost").value=addon_cost; 

            var item_cost=document.getElementById("total_cost").value;
var total_cost=parseFloat(item_cost)+parseFloat(addon_cost);
              document.getElementById("total_cost").value=total_cost; 
              document.getElementById("order_total_cost").value=total_cost; 

          }
        });
  }
  </script>

      <script type="text/javascript">
        function display_factory_item_cost(vendor_id)
        {
          // alert("display_factory_item_cost");
          var item_id=document.getElementById("item_id").value;
          var fabric_id=document.getElementById("fabric_id").value;
          var quantity_id=document.getElementById("quantity_id").value;
          var total=document.getElementById("total_qty").value;
          // alert(item_id+"v"+vendor_id+" q"+quantity_id+"f"+fabric_id)

          $.ajax(
          {
            type:"POST",
            url:"details/display_factory_item_cost.php",
            dataType:"json",
            data:{
              quantity_id:quantity_id,
              vendor_id:vendor_id,
              fabric_id:fabric_id,
                    item_id:item_id
            },

            success: function(data)

            {
                     // alert(data);
 // alert(data);
              var factory_item_cost=data.factory_item_cost;
              var factory_fabric_price=data.factory_fabric_price;
              // alert(factory_fabric_price);
              // alert(factory_item_cost);
              var factory_item_cost_sum=total*factory_item_cost;
              var factory_fabric_price_sum=total*factory_fabric_price;
              // alert(factory_fabric_price_sum);
              document.getElementById("factory_item_cost").value=factory_item_cost_sum; 
              document.getElementById("factory_fabric_cost").value=factory_fabric_price_sum; 
              
              document.getElementById("factory_total_cost").value=factory_item_cost_sum+factory_fabric_price_sum; 
              document.getElementById("factory_order_total_cost").value=factory_total_cost; 
              display_factory_addon_cost(vendor_id);
              // display_fabric_cost(vendor_id);


    
}    
});

          // var tax=(parseFloat(sum)*parseFloat(selling_price))/100;
          
        }

      </script>

 


    <script type="text/javascript">
  function display_factory_addon_cost(vendor_id)
  {
// alert("display_factory_addon_cost");
    var total= document.getElementById("total_qty").value
    var quantity_id= document.getElementById("quantity_id").value
    // alert("display_factory_addon_cost");
    var addon_array=[];

    var m=0;
    var addon_element=document.getElementsByName('addon_id');
    for (var i = 0; i <addon_element.length; i++) 
      {
        var addon_id=addon_element[i].value;
        if (addon_id!="")
        {
        addon_array[m]=addon_id;
        m++;
        }
      }
    var addon_array_json=JSON.stringify(addon_array);
    // alert(addon_array_json);
        $.ajax({
          type:"POST",
          url:"details/display_factory_addon_cost.php",
          dataType:"json",
          data:{
            addon_array_json:addon_array_json,
            quantity_id:quantity_id,
            vendor_id:vendor_id

                },
          success:function(data)
          {
              // alert(data);
              var sum4=data.sum4;
              // alert("sum");
              // alert(sum);
              var factory_addon_cost=total*sum4
              document.getElementById("factory_addon_cost").value=factory_addon_cost; 
                   // var factory_addon_cost= document.getElementById("factory_addon_cost").value;
  var factory_item_cost=document.getElementById("factory_item_cost").value;
  // alert(factory_item_cost);
  var factory_total_cost=parseFloat(factory_item_cost)+parseFloat(factory_addon_cost);
  
              document.getElementById("factory_total_cost").value=factory_total_cost; 
              document.getElementById("factory_order_total_cost").value=factory_total_cost; 

          }
        });
  }
  </script>
     <script type="text/javascript">
  function add_addon(x,y) {
    
    var addon_row_count=document.getElementById("addon_row_count").value;
  // var sum=document.getElementById("total_amount").value;
  addon_row_count=parseInt(addon_row_count)+1;
  document.getElementById('addon_row_count').value=addon_row_count;
  // document.getElementById('total_amount').value=sum;

  var row_id = x.parentNode.parentNode.rowIndex;
  var x=row_id;
  var table = document.getElementById(y);
  var row = table.insertRow(x);
  var cell1 = row.insertCell(0);
  var cell2 = row.insertCell(1);
  

// var cell7 = row.insertCell(6);


cell1.innerHTML ='  <select id="addon_id" class="form-control input-md" name="addon_id" >          <option style="color: grey" value="" >select addon          </option>          <?php  
            $query=mysqli_query($conn,"SELECT * from addons");
            while($fetch=mysqli_fetch_array($query))
            {
              ?>
              <option value="<?php echo $fetch ['addon_id']; ?>"><?php echo  $fetch ['addon_id'].".".$fetch ['addon']."-".$fetch ['addon_price1'].",".$fetch ['addon_price2'].",".$fetch ['addon_price3'];?> </option><?php
            }
            ?>    </select>   ';

cell2.innerHTML = '<button id="add" name="add" class="btn btn-warning" onclick="delete_addon(this)">-</button></td>';



}

</script>
<script>
  function  delete_addon(element) {
    var row_id = element.parentNode.parentNode.rowIndex;
    document.getElementById("addon_table1").deleteRow(row_id);
    add_total();
  }
</script>
<script type="text/javascript">
  function display_balance()
  {
    var order_total_cost=document.getElementById("order_total_cost").value;
    var advance_amount=document.getElementById("advance_amount").value;
    var balance_amount=parseFloat(order_total_cost)-parseFloat(advance_amount);
    document.getElementById("balance_amount").value=balance_amount;
  }
</script>
<script type="text/javascript">
  function display_factory_balance()
  {
    var order_total_cost=document.getElementById("factory_order_total_cost").value;
    var advance_amount=document.getElementById("factory_advance_amount").value;
    var balance_amount=parseFloat(order_total_cost)-parseFloat(advance_amount);
    document.getElementById("factory_balance_amount").value=balance_amount;
  }
</script>
    
    </body>
    </html>